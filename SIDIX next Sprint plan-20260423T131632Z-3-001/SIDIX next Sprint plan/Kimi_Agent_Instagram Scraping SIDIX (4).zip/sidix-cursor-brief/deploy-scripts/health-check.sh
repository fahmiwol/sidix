#!/bin/bash
# =============================================================================
# SIDIX Health Check Script
# Di-run otomatis setiap 5 menit oleh PM2 cron
# =============================================================================

HEALTH_URL="http://localhost:8765/health"
ALERT_WEBHOOK=""  # Isi dengan Discord/Slack webhook URL kalau mau alert
LOG_FILE="/root/sidix/logs/health-$(date +%Y%m%d).log"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

mkdir -p /root/sidix/logs

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Health check starting..." >> "$LOG_FILE"

# Check 1: HTTP Health Endpoint
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "$HEALTH_URL" 2>/dev/null || echo "000")

if [ "$HTTP_CODE" != "200" ]; then
    log "WARNING: Health endpoint returned HTTP $HTTP_CODE"
    
    # Coba restart otomatis (hanya sekali, hindari loop)
    if [ -f "/tmp/sidix-restart-lock" ]; then
        log "INFO: Restart lock exists, skipping auto-restart"
    else
        log "INFO: Attempting auto-restart..."
        touch /tmp/sidix-restart-lock
        pm2 restart sidix-backend >> "$LOG_FILE" 2>&1
        sleep 10
        
        # Verifikasi restart
        NEW_CODE=$(curl -s -o /dev/null -w "%{http_code}" "$HEALTH_URL" 2>/dev/null || echo "000")
        if [ "$NEW_CODE" = "200" ]; then
            log "SUCCESS: Auto-restore successful"
            rm -f /tmp/sidix-restart-lock
        else
            log "CRITICAL: Auto-restore FAILED. Manual intervention required!"
            # Kirim alert kalau webhook configured
            if [ -n "$ALERT_WEBHOOK" ]; then
                curl -s -X POST "$ALERT_WEBHOOK" \
                    -H "Content-Type: application/json" \
                    -d "{\"text\":\"🚨 SIDIX CRITICAL: Health check failed dan auto-restart gagal. HTTP: $NEW_CODE\"}" >> "$LOG_FILE" 2>&1
            fi
        fi
    fi
else
    log "OK: Health check passed (HTTP 200)"
    # Clear restart lock kalau health normal
    rm -f /tmp/sidix-restart-lock
fi

# Check 2: Disk Space
DISK_USAGE=$(df -h / | awk 'NR==2 {print $5}' | tr -d '%')
if [ "$DISK_USAGE" -gt 85 ]; then
    log "WARNING: Disk usage high: ${DISK_USAGE}%"
fi

# Check 3: Memory
MEM_USAGE=$(free | grep Mem | awk '{printf("%.0f", $3/$2 * 100.0)}')
if [ "$MEM_USAGE" -gt 90 ]; then
    log "WARNING: Memory usage high: ${MEM_USAGE}%"
fi

# Check 4: Ollama Status
OLLAMA_STATUS=$(curl -s http://localhost:11434/api/tags >/dev/null && echo "UP" || echo "DOWN")
if [ "$OLLAMA_STATUS" = "DOWN" ]; then
    log "WARNING: Ollama is DOWN"
fi

# Check 5: Database
DB_STATUS=$(pg_isready -h localhost -p 5432 2>/dev/null && echo "UP" || echo "DOWN")
if [ "$DB_STATUS" = "DOWN" ]; then
    log "WARNING: PostgreSQL is DOWN"
fi

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Health check completed." >> "$LOG_FILE"
