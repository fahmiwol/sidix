# DEPLOYMENT GUIDE — SIDIX VPS
## Dari GitHub ke Production (2026-04-25)

---

## 🎯 TUJUAN

Guide ini menjelaskan cara mengubah code di GitHub menjadi **live running di VPS** dengan satu command.

> ⚠️ **PENTING:** `git push` tidak otomatis live di VPS. Perlu langkah deploy manual atau otomatis.

---

## 📋 PRE-REQUISITES

### Di VPS (sudah harus terinstall):

| Component | Command Check | Status |
|-----------|--------------|--------|
| Git | `git --version` | ✅ Sudah ada |
| Python 3.10+ | `python3 --version` | ✅ |
| pip | `pip --version` | ✅ |
| Node.js + npm | `node --version` | ✅ (untuk dashboard) |
| PM2 | `pm2 --version` | ⬜ Install kalau belum |
| PostgreSQL | `psql --version` | ⬜ Kalau pakai database |
| Ollama | `ollama --version` | ⬜ Untuk inference |

### Install PM2 (kalau belum):

```bash
npm install -g pm2
pm2 startup  # Setup auto-start saat boot
```

### Install Ollama (kalau belum):

```bash
curl -fsSL https://ollama.com/install.sh | sh
ollama pull qwen2.5:7b  # atau model yang dipakai SIDIX
```

---

## 🚀 QUICK START — Satu Command Deploy

```bash
# 1. Masuk ke repo
cd ~/sidix

# 2. Jalankan deploy script
bash deploy-scripts/deploy.sh
```

**Script ini akan:**
1. ✅ Check status repo
2. ✅ Backup otomatis
3. ✅ `git pull origin main`
4. ✅ Install dependencies
5. ✅ Database migrations (kalau ada)
6. ✅ Restart services via PM2
7. ✅ Health check otomatis
8. ✅ Tampilkan summary

---

## 🔄 WORKFLOW HARIAN

### Scenario 1: Ada update baru di GitHub

```bash
cd ~/sidix
bash deploy-scripts/deploy.sh
```

### Scenario 2: Edit config lokal, perlu restart

```bash
cd ~/sidix
bash deploy-scripts/restart.sh
```

### Scenario 3: Cek status semua services

```bash
pm2 status
```

### Scenario 4: Lihat log real-time

```bash
pm2 logs sidix-backend    # Log backend
pm2 logs sidix-dashboard  # Log dashboard
pm2 logs sidix-health     # Log health check
```

### Scenario 5: Rollback (kalau deploy rusak)

```bash
# 1. Cek backup yang tersedia
ls ~/.sidix-backups/

# 2. Restore dari backup
BACKUP="~/.sidix-backups/backup-20260425_120000.tar.gz"
tar -xzf "$BACKUP" -C ~/sidix --strip-components=0

# 3. Restart
bash deploy-scripts/restart.sh
```

---

## 📁 STRUKTUR DEPLOYMENT

```
~/sidix/                          # Repo utama
├── deploy-scripts/
│   ├── deploy.sh                 # ⭐ Script deploy utama
│   ├── restart.sh                # Quick restart tanpa pull
│   ├── ecosystem.config.js       # PM2 config (semua services)
│   └── health-check.sh         # Auto health monitor
├── logs/                         # Log files (auto-created)
│   ├── out.log
│   ├── error.log
│   └── health-20260425.log
└── .sidix-backups/               # Backup otomatis
    ├── backup-20260425_120000.tar.gz
    └── ...
```

---

## ⚙️ KONFIGURASI PM2

### Start semua services:

```bash
pm2 start ecosystem.config.js --env production
pm2 save
```

### Start HANYA backend (tanpa dashboard):

```bash
pm2 start ecosystem.config.js --only sidix-backend
```

### Enable MCP server (manual, untuk keamanan):

```bash
pm2 start ecosystem.config.js --only sidix-mcp
```

### Stop semua:

```bash
pm2 stop all
```

### Delete semua dari PM2:

```bash
pm2 delete all
```

---

## 🔐 KEAMANAN — MCP DEFAULT OFF

Sesuai policy SIDIX:

```
SIDIX_MCP_ENABLED=false    # Default: OFF
```

### Untuk enable MCP (hanya kalau perlu):

```bash
# Method 1: Environment variable
export SIDIX_MCP_ENABLED=true
pm2 restart sidix-backend

# Method 2: Start MCP server terpisah
pm2 start ecosystem.config.js --only sidix-mcp
```

### Check status MCP:

```bash
curl http://localhost:8766/health
```

---

## 🩺 HEALTH MONITORING

### Auto Health Check (setiap 5 menit):

Sudah dikonfigurasi di PM2. Check log:

```bash
tail -f ~/sidix/logs/health-$(date +%Y%m%d).log
```

### Manual Health Check:

```bash
bash deploy-scripts/health-check.sh
```

### What health check monitors:

| Check | Pass | Fail Action |
|-------|------|-------------|
| HTTP /health | HTTP 200 | Auto-restart once |
| Disk space | < 85% | Warning only |
| Memory | < 90% | Warning only |
| Ollama | UP | Warning only |
| PostgreSQL | UP | Warning only |

---

## 🆘 TROUBLESHOOTING

### Problem: "Port 8765 already in use"

```bash
# Find process using port
sudo lsof -i :8765

# Kill it
sudo kill -9 <PID>

# Restart
pm2 restart sidix-backend
```

### Problem: "Permission denied"

```bash
# Make scripts executable
chmod +x deploy-scripts/*.sh

# Check ownership
ls -la ~/sidix/
```

### Problem: "Dependencies missing after pull"

```bash
# Manual install
pip install -r requirements.txt
npm install

# Restart
pm2 restart all
```

### Problem: "Ollama model not found"

```bash
# Pull model
ollama pull qwen2.5:7b

# Verify
ollama list
```

### Problem: "Database connection failed"

```bash
# Check PostgreSQL status
sudo systemctl status postgresql

# Start if stopped
sudo systemctl start postgresql

# Check connection
psql -h localhost -U sidix -d sidix -c "SELECT 1"
```

---

## 📊 PM2 CHEAT SHEET

| Command | Fungsi |
|---------|--------|
| `pm2 status` | Lihat semua services |
| `pm2 logs` | Lihat log semua services |
| `pm2 logs sidix-backend` | Log specific service |
| `pm2 monit` | Interactive monitor (h-top style) |
| `pm2 restart all` | Restart semua |
| `pm2 reload all` | Zero-downtime reload |
| `pm2 stop sidix-backend` | Stop specific service |
| `pm2 delete sidix-backend` | Remove dari PM2 |
| `pm2 save` | Save current config |
| `pm2 startup` | Setup auto-start saat boot |
| `pm2 show sidix-backend` | Detail info service |
| `pm2 describe sidix-backend` | Full metrics |

---

## 🎯 CHECKLIST DEPLOYMENT

- [ ] VPS sudah punya PM2 (`npm install -g pm2`)
- [ ] Ollama terinstall dan model sudah di-pull
- [ ] PostgreSQL running (kalau pakai)
- [ ] Repo sudah clone: `~/sidix/`
- [ ] Deploy scripts sudah executable: `chmod +x deploy-scripts/*.sh`
- [ ] PM2 ecosystem sudah dikonfigurasi
- [ ] `git remote` mengarah ke GitHub yang benar
- [ ] `.env` atau environment variables sudah diset
- [ ] Port 8765 (backend) dan 3000 (dashboard) available
- [ ] Firewall allow port yang dipakai (kalau perlu)

---

## 📎 CATATAN UNTUK AGEN BERIKUTNYA

Ketika user mengatakan "deploy ke VPS", artinya:
1. VPS sudah punya repo SIDIX di `~/sidix/`
2. Jalankan: `cd ~/sidix && bash deploy-scripts/deploy.sh`
3. Verifikasi: `pm2 status` dan `curl http://localhost:8765/health`
4. Kalau health check PASS → deploy sukses

Jangan lupa: **MCP default OFF** — enable manual saja kalau perlu.

---

*Deploy guide ini selaras dengan HANDOFF_2026-04-25_SYNC_TYPO_JIWA_PLUGIN_ORBIT.md*
