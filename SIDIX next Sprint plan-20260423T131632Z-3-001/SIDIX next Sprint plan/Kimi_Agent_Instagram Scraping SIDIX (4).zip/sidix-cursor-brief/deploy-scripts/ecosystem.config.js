/**
 * PM2 Ecosystem Config untuk SIDIX
 * 
 * Cara pakai:
 *   pm2 start ecosystem.config.js
 *   pm2 save
 *   pm2 startup  (untuk auto-start saat boot)
 * 
 * Monitoring:
 *   pm2 status
 *   pm2 logs sidix
 *   pm2 monit
 */

module.exports = {
  apps: [
    // Main SIDIX Backend
    {
      name: 'sidix-backend',
      script: './brain/main.py',
      interpreter: 'python3',
      cwd: '/root/sidix',  // Sesuaikan dengan path repo di VPS

      // Environment
      env: {
        NODE_ENV: 'development',
        SIDIX_MODE: 'development',
        LOG_LEVEL: 'info'
      },
      env_production: {
        NODE_ENV: 'production',
        SIDIX_MODE: 'production',
        LOG_LEVEL: 'info',
        PORT: 8765,
        HOST: '0.0.0.0'
      },

      // Process management
      instances: 1,           // Jalankan 1 instance (scale manual kalau perlu)
      exec_mode: 'fork',      // Python tidak support cluster mode

      // Restart policy
      autorestart: true,
      max_restarts: 5,
      min_uptime: '10s',
      restart_delay: 3000,

      // Resource limits
      max_memory_restart: '2G',  // Restart kalau > 2GB RAM

      // Logging
      log_file: './logs/combined.log',
      out_file: './logs/out.log',
      error_file: './logs/error.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,

      // Health monitoring
      listen_timeout: 10000,
      kill_timeout: 5000,
      wait_ready: true,

      // Watch mode (auto-restart saat development)
      // Matikan di production!
      watch: false,
      ignore_watch: [
        'node_modules',
        'logs',
        '.git',
        '__pycache__',
        '*.pyc',
        'uploads',
        'temp'
      ],

      // Advanced
      instance_var: 'INSTANCE_ID',
      pmx: true,
      automation: false,
      vizion: false,

      // Custom environment variables
      env_SIDIX: {
        // MCP default OFF (sesuai kebijakan keamanan)
        SIDIX_MCP_ENABLED: 'false',
        SIDIX_MCP_HOST: 'localhost',
        SIDIX_MCP_PORT: '8766',
        
        // Ollama (CPU mode default)
        OLLAMA_HOST: 'http://localhost:11434',
        OLLAMA_MODEL: 'qwen2.5:7b',
        
        // Database
        DATABASE_URL: 'postgresql://sidix:sidix@localhost:5432/sidix',
        
        // Knowledge Graph
        MIZAN_ENABLED: 'true',
        
        // 7 Pilar Jiwa
        JIWA_NAFS_ENABLED: 'true',
        JIWA_AQL_ENABLED: 'true',
        JIWA_QALB_ENABLED: 'true',
        JIWA_RUH_ENABLED: 'true',
        JIWA_HAYAT_ENABLED: 'true',
        JIWA_ILM_ENABLED: 'true',
        JIWA_HIKMAH_ENABLED: 'true',
        
        // Typo Resilience
        TYPO_RESILIENCE_ENABLED: 'true',
        TYPO_MULTILINGUAL_ENABLED: 'true',
        
        // Self-healing
        SELF_HEALING_ENABLED: 'true',
        HEALTH_CHECK_INTERVAL: '60',
        
        // QLoRA Training (OFF secara default, aktifkan manual)
        QLORA_TRAINING_ENABLED: 'false',
        
        // Web Dashboard
        DASHBOARD_ENABLED: 'true',
        DASHBOARD_PORT: '3000'
      }
    },

    // MCP Server (terpisah, default OFF)
    {
      name: 'sidix-mcp',
      script: './brain/sociometer/mcp_server.py',
      interpreter: 'python3',
      cwd: '/root/sidix',
      
      env: {
        NODE_ENV: 'development',
        MCP_MODE: 'stdio'  // atau 'streamable-http'
      },
      env_production: {
        NODE_ENV: 'production',
        MCP_MODE: 'streamable-http',
        MCP_PORT: 8766,
        MCP_HOST: '0.0.0.0'
      },

      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      max_restarts: 3,
      restart_delay: 5000,

      // Resource limits
      max_memory_restart: '1G',

      log_file: './logs/mcp-combined.log',
      out_file: './logs/mcp-out.log',
      error_file: './logs/mcp-error.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',

      // MCP server start HANYA kalau di-enable
      // Gunakan: pm2 start ecosystem.config.js --only sidix-mcp
      // atau set SIDIX_MCP_ENABLED=true di .env
      
      listen_timeout: 10000,
      kill_timeout: 5000,

      // Jangan auto-start MCP server
      autostart: false  // Manual start saja untuk keamanan
    },

    // Dashboard Web UI (Node.js)
    {
      name: 'sidix-dashboard',
      script: './dashboard/server.js',
      cwd: '/root/sidix',

      env: {
        NODE_ENV: 'development',
        PORT: 3000
      },
      env_production: {
        NODE_ENV: 'production',
        PORT: 3000,
        API_URL: 'http://localhost:8765'
      },

      instances: 1,
      exec_mode: 'fork',
      autorestart: true,

      log_file: './logs/dashboard-combined.log',
      out_file: './logs/dashboard-out.log',
      error_file: './logs/dashboard-error.log',

      max_memory_restart: '512M',
      
      autostart: true
    },

    // Health Monitor (cron job style)
    {
      name: 'sidix-health',
      script: './scripts/health-check.sh',
      interpreter: 'bash',
      cwd: '/root/sidix',

      // Jalankan setiap 5 menit
      cron_restart: '*/5 * * * *',
      
      instances: 1,
      exec_mode: 'fork',
      autorestart: false,  // Cron-based, no need autorestart
      
      log_file: './logs/health-combined.log',
      error_file: './logs/health-error.log',

      autostart: true
    }
  ],

  // Deployment configuration (kalau pakai PM2 deploy)
  deploy: {
    production: {
      user: 'root',
      host: ['your-vps-ip'],
      ref: 'origin/main',
      repo: 'https://github.com/fahmiwol/sidix.git',
      path: '/root/sidix',
      'post-deploy': 'bash deploy-scripts/deploy.sh'
    }
  }
};
