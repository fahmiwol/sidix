#!/bin/bash
# =============================================================================
# SIDIX VPS Deploy Script
# Tugas: Pull latest code, install dependencies, restart services
# Author: SIDIX Team | Date: 2026-04-25
# =============================================================================

set -e  # Exit on error

# Colors untuk output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Konfigurasi
REPO_DIR="${SIDIX_HOME:-$HOME/sidix}"
GITHUB_REPO="https://github.com/fahmiwol/sidix.git"
BRANCH="main"
BACKUP_DIR="$HOME/.sidix-backups"
LOG_FILE="$REPO_DIR/logs/deploy-$(date +%Y%m%d_%H%M%S).log"

# Fungsi logging
log() {
    echo -e "${GREEN}[SIDIX-DEPLOY]${NC} $1" | tee -a "$LOG_FILE"
}

warn() {
    echo -e "${YELLOW}[SIDIX-WARN]${NC} $1" | tee -a "$LOG_FILE"
}

error() {
    echo -e "${RED}[SIDIX-ERROR]${NC} $1" | tee -a "$LOG_FILE"
}

info() {
    echo -e "${BLUE}[SIDIX-INFO]${NC} $1" | tee -a "$LOG_FILE"
}

# =============================================================================
# PRE-DEPLOY CHECKS
# =============================================================================

echo "=========================================="
echo "  SIDIX VPS Deploy Script"
echo "  $(date)"
echo "=========================================="

# Check if repo exists
if [ ! -d "$REPO_DIR/.git" ]; then
    error "Repo tidak ditemukan di $REPO_DIR"
    info "Clone terlebih dahulu:"
    info "  git clone $GITHUB_REPO $REPO_DIR"
    exit 1
fi

cd "$REPO_DIR"

# Check git status
info "Checking repository status..."
git fetch origin "$BRANCH"
LOCAL=$(git rev-parse HEAD)
REMOTE=$(git rev-parse origin/$BRANCH)

if [ "$LOCAL" = "$REMOTE" ]; then
    warn "Repo sudah up-to-date (tidak ada perubahan baru)."
    warn "Jika tetap ingin restart service, gunakan: ./scripts/restart.sh"
    read -p "Lanjutkan restart saja? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        info "Deploy dibatalkan."
        exit 0
    fi
    SKIP_PULL=1
else
    info "Ada update baru. Local: ${LOCAL:0:7} → Remote: ${REMOTE:0:7}"
    SKIP_PULL=0
fi

# Check disk space
DISK_USAGE=$(df -h / | awk 'NR==2 {print $5}' | tr -d '%')
if [ "$DISK_USAGE" -gt 90 ]; then
    error "Disk usage tinggi: ${DISK_USAGE}%! Bersihkan disk dulu."
    exit 1
fi
info "Disk usage: ${DISK_USAGE}%"

# =============================================================================
# BACKUP (Sebelum deploy)
# =============================================================================

if [ "$SKIP_PULL" = "0" ]; then
    info "Membuat backup..."
    mkdir -p "$BACKUP_DIR"
    BACKUP_NAME="backup-$(date +%Y%m%d_%H%M%S).tar.gz"
    
    # Backup file penting (kecuali node_modules, .git, dll)
    tar -czf "$BACKUP_DIR/$BACKUP_NAME" \
        --exclude='node_modules' \
        --exclude='__pycache__' \
        --exclude='.git' \
        --exclude='*.pyc' \
        --exclude='logs' \
        -C "$REPO_DIR" . 2>/dev/null || true
    
    log "Backup tersimpan: $BACKUP_DIR/$BACKUP_NAME"
fi

# =============================================================================
# GIT PULL
# =============================================================================

if [ "$SKIP_PULL" = "0" ]; then
    log "Pulling latest code dari origin/$BRANCH..."
    git pull origin "$BRANCH" | tee -a "$LOG_FILE"
    log "Pull selesai."
fi

# =============================================================================
# INSTALL DEPENDENCIES
# =============================================================================

log "Menginstall dependencies..."

# Python dependencies
if [ -f "requirements.txt" ]; then
    info "Installing Python requirements..."
    pip install -r requirements.txt --quiet | tee -a "$LOG_FILE" || warn "pip install selesai dengan warnings"
fi

# Node.js dependencies (jika ada)
if [ -f "package.json" ]; then
    info "Installing Node.js packages..."
    npm install --silent | tee -a "$LOG_FILE" || warn "npm install selesai dengan warnings"
fi

# =============================================================================
# DATABASE MIGRATIONS (kalau ada perubahan schema)
# =============================================================================

if [ -f "alembic.ini" ]; then
    info "Running database migrations..."
    alembic upgrade head | tee -a "$LOG_FILE" || warn "Alembic migration selesai"
fi

# =============================================================================
# RESTART SERVICES
# =============================================================================

log "Restarting SIDIX services..."

# Method 1: PM2 (preferred)
if command -v pm2 &> /dev/null && [ -f "ecosystem.config.js" ]; then
    info "Restarting via PM2..."
    pm2 restart ecosystem.config.js --env production | tee -a "$LOG_FILE"
    pm2 save
    
# Method 2: systemd service
elif [ -f "/etc/systemd/system/sidix.service" ]; then
    info "Restarting via systemd..."
    sudo systemctl restart sidix
    sleep 2
    sudo systemctl status sidix --no-pager | tee -a "$LOG_FILE"
    
# Method 3: Direct process (fallback)
else
    warn "PM2 atau systemd tidak ditemukan. Gunakan manual restart:"
    warn "  python brain/main.py &"
    warn "  atau setup PM2: npm install -g pm2"
fi

# =============================================================================
# HEALTH CHECK
# =============================================================================

log "Running health check..."
sleep 3  # Tunggu service start

HEALTH_URL="http://localhost:8765/health"
MAX_RETRIES=5
RETRY=0

while [ $RETRY -lt $MAX_RETRIES ]; do
    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "$HEALTH_URL" 2>/dev/null || echo "000")
    
    if [ "$HTTP_CODE" = "200" ]; then
        log "✅ Health check PASS! SIDIX berjalan normal."
        break
    fi
    
    RETRY=$((RETRY + 1))
    warn "Health check attempt $RETRY/$MAX_RETRIES... (HTTP: $HTTP_CODE)"
    sleep 2
done

if [ $RETRY -eq $MAX_RETRIES ]; then
    error "❌ Health check FAIL! SIDIX tidak merespon."
    error "Cek log: pm2 logs sidix"
    error "Atau: journalctl -u sidix -f"
    exit 1
fi

# =============================================================================
# SUMMARY
# =============================================================================

NEW_COMMIT=$(git rev-parse --short HEAD)

echo ""
echo "=========================================="
echo "  DEPLOY SELESAI ✅"
echo "=========================================="
echo "  Commit: $NEW_COMMIT"
echo "  Time: $(date)"
echo "  Log: $LOG_FILE"
echo "  Backup: $BACKUP_DIR/$BACKUP_NAME"
echo "=========================================="
echo ""
echo "Perintah berguna:"
echo "  pm2 logs sidix        ← Lihat log real-time"
echo "  pm2 status            ← Status semua services"
echo "  pm2 monit             ← Monitor interactive"
echo ""
