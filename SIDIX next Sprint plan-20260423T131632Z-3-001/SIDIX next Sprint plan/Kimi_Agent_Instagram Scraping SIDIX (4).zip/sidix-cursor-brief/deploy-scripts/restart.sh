#!/bin/bash
# =============================================================================
# SIDIX Quick Restart Script
# Untuk restart cepat tanpa pull (misal setelah edit config)
# =============================================================================

set -e

echo "=========================================="
echo "  SIDIX Quick Restart"
echo "  $(date)"
echo "=========================================="

# Check PM2
if ! command -v pm2 &> /dev/null; then
    echo "❌ PM2 tidak ditemukan. Install dulu: npm install -g pm2"
    exit 1
fi

echo "🔄 Restarting SIDIX services..."

# Restart main backend
pm2 restart sidix-backend

# Restart dashboard
pm2 restart sidix-dashboard

# Restart health monitor
pm2 restart sidix-health

# MCP hanya restart kalau sudah aktif
if pm2 show sidix-mcp &> /dev/null; then
    pm2 restart sidix-mcp
fi

sleep 2

echo ""
echo "📊 Status services:"
pm2 status

echo ""
echo "✅ Restart selesai!"
echo ""
echo "Cek log:"
echo "  pm2 logs sidix-backend"
echo "  pm2 logs sidix-dashboard"
