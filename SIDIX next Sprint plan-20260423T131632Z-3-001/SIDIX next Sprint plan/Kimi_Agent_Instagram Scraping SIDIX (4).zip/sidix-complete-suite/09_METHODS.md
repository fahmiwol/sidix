# 09 — METHODS & PROCEDURES
## How SIDIX Works Internally — Step by Step

**Version:** 1.0
**Date:** 2026-04-25
**For:** Developers who need to understand internal mechanics
**Principle:** Every method must be reproducible, testable, and documented.

---

## 1. MESSAGE PROCESSING METHOD

### 1.1 Standard Flow (Chat Mode)

```
Step 1: RECEIVE
├─ Parse HTTP/WebSocket request
├─ Authenticate user (JWT + Redis session)
├─ Extract: query, client_id, conversation_id, persona_hint
└─ Log to audit_logs table

Step 2: MULTILINGUAL PIPELINE
├─ Script Detector: identify script (Latin/Arabic/CJK)
├─ Language Detector: identify language (id/en/ar/ms/tl/hi)
├─ Typo Corrector: correct typos using language-specific dictionary
├─ Semantic Matcher: cross-lingual intent detection
└─ Cultural Responder: prepare response language setting

Step 3: INTENT CLASSIFICATION
├─ Classify into 40+ intent categories:
│  ├── general_chat
│  ├── creative_request (image/video/audio)
│  ├── code_request
│  ├── analysis_request
│  ├── brand_request
│  ├── campaign_request
│  ├── research_request
│  ├── religious_question
│  ├── technical_question
│  └── tool_invocation
└─ Confidence threshold: 0.70

Step 4: CONTEXT LOADING
├─ Load conversation history (last 10 messages)
├─ Load client branch context (if agency mode)
│  ├── Brand KG (colors, tone, history)
│  ├── Campaign history
│  └── Preferences
├─ Load active persona settings
└─ Load Maqashid mode preference

Step 5: PERSONA SELECTION
├─ If persona_hint provided → use that
├─ Else auto-select based on intent:
│  ├── creative_request → UTZ or AYMAN
│  ├── research_request → ABOO
│  ├── code_request → ALEY (general) or ABOO (technical)
│  ├── campaign_request → AYMAN
│  └── general_chat → ALEY
└─ Load persona system prompt

Step 6: KNOWLEDGE ROUTING (Nafs)
├─ Classify query topic
├─ Select knowledge layers:
│  ├── "agama", "etika", "hukum" → STATIC + DYNAMIC
│  ├── "ihos", "maqashid", "sidix_system" → DYNAMIC
│  ├── "teknologi", "umum" → PARAMETRIC
│  └── Mixed → PARAMETRIC (60%) + DYNAMIC (30%) + STATIC (10%)
└─ Query each layer

Step 7: TOOL SELECTION (if needed)
├─ If intent requires tool:
│  ├── image generation → generate_image tool
│  ├── code execution → code_sandbox tool
│  ├── web search → search_web tool
│  ├── analysis → code_analyze tool
│  └── ... (35 tools available)
└─ Execute tool and capture result

Step 8: RESPONSE GENERATION
├─ Build context window:
│  ├── System prompt (persona + Maqashid mode)
│  ├── Knowledge context (from layers + tools)
│  ├── Conversation history
│  └── User query
├─ Send to Ollama (LLM inference)
└─ Receive raw response

Step 9: QUALITY CONTROL (Hayat)
├─ CQF scoring (10 criteria)
├─ If score < 8.0 and iterations < 3:
│  ├── Analyze weaknesses
│  ├── Refine prompt
│  ├── Regenerate
│  └── Re-evaluate
└─ Final quality check

Step 10: EPISTEMIC LABELING
├─ Scan response for factual claims
├─ Label each claim:
│  ├── Verified by corpus/KG → [FACT]
│  ├── Reasoned position → [OPINION]
│  ├── Unverified → [CLAIM]
│  ├── Cannot verify → [UNKNOWN]
│  └── AI-generated content → [CREATED]
└─ Apply labels inline

Step 11: MAQASHID FILTER
├─ Check output against Maqashid rules:
│  ├── Hifdz ad-Din → no blasphemy, respectful
│  ├── Hifdz an-Nafs → no harm, no self-harm
│  ├── Hifdz an-Nasl → no sexual/explicit
│  ├── Hifdz al-Mal → no fraud/scams
│  └── Hifdz al-Aql → no intoxication promotion
├─ If violation detected:
│  ├── Block output
│  ├── Return error with explanation
│  └── Log violation
└─ If pass → continue

Step 12: RESPONSE FORMATTING
├─ Format as markdown
├─ Attach generated assets (images, videos, etc.)
├─ Add metadata footer:
│  ├── CQF score
│  ├── Persona used
│  ├── Maqashid mode
│  ├── Knowledge layers
│  └── Sanad chain
└─ Prepare WebSocket chunks for streaming

Step 13: DELIVERY
├─ Stream response via WebSocket (chunk by chunk)
├─ Store in messages table
├─ Update conversation metadata
└─ Send notification if approval needed

Step 14: LEARNING CAPTURE (Aql)
├─ Anonymize (remove PII)
├─ Score interaction quality
├─ If quality >= 7.0:
│  ├── Extract to training_pairs
│  ├── Update Knowledge Graph
│  └── Mark for future training
└─ Log to analytics

Step 15: HEALTH CHECK (Qalb)
├─ Check system metrics
├─ If degraded/sick/critical → trigger auto-heal
└─ Log to health_checks
```

### 1.2 Creative Generation Flow (Raudah Mode)

```
Step 1: BRIEF PARSING
├─ Extract: client, objective, audience, budget, timeline
├─ Load client brand KG
├─ Identify required deliverables
└─ Create project record

Step 2: TASK DECOMPOSITION
├─ Break into sub-tasks:
│  ├── Research (ABOO)
│  ├── Concept (AYMAN)
│  ├── Visuals (UTZ)
│  ├── Copy (ALEY)
│  ├── Production (OOMAR)
│  └── Review (all)
└─ Create TaskGraph DAG

Step 3: PARALLEL EXECUTION
├─ Execute independent tasks in parallel:
│  ├── ABOO scans trends + competitors
│  ├── AYMAN brainstorms concepts
│  └── UTZ prepares style references
├─ Synchronize at dependency points
└─ Pass outputs to dependent tasks

Step 4: CONSENSUS
├─ When agents produce alternatives:
│  ├── Score each against criteria
│  ├── Weight by agent expertise
│  ├── Select or synthesize hybrid
│  └── Apply Maqashid filter
└─ Record decision rationale

Step 5: QUALITY GATE
├─ CQF scoring per deliverable
├─ Brand alignment check
├─ Maqashid filter
└─ Iteration if needed

Step 6: PACKAGE & DELIVER
├─ Bundle all assets
├─ Generate presentation deck
├─ Create tracking links
└─ Present to user for approval

Step 7: FEEDBACK LOOP
├─ Collect user feedback
├─ If approved → schedule/deploy
├─ If revision → re-route to agent
└─ Log learnings for future projects
```

---

## 2. TRAINING METHOD (Jariyah v3)

### 2.1 Data Collection

```
Source 1: User Conversations
├─ Filter: conversations with thumbs_up or high CQF
├─ Anonymize: remove emails, names, phones, addresses
├─ Extract: (query, response, context, persona)
└─ Store: training_pairs table

Source 2: Web Crawling (Ilm)
├─ Identify knowledge gaps
├─ Crawl ethical sources (robots.txt compliant)
├─ Extract facts + Sanad chain
├─ Curate: manual review of top-quality items
└─ Store: training_pairs + kg_nodes

Source 3: Manual Curation
├─ Domain experts contribute Q&A pairs
├─ Religious scholars verify Islamic content
├─ Creative professionals verify marketing content
└─ Store: training_pairs (immediate approval)
```

### 2.2 Quality Assurance

```
Step 1: CQF Auto-Scoring
├─ Score each pair on 10 criteria
├─ Threshold: >= 7.0 to proceed
└─ Reject: < 7.0 with reason

Step 2: Human Review (for sensitive topics)
├─ Religious content → Islamic scholar review
├─ Medical content → Medical professional review
├─ Legal content → Legal professional review
└─ Mark: approved, rejected, needs_revision

Step 3: Deduplication
├─ Check for near-duplicate queries
├─ Keep highest quality version
└─ Merge similar responses

Step 4: Balance
├─ Ensure category balance (not 90% general chat)
├─ Ensure language balance
├─ Ensure persona balance
└─ Re-sample if unbalanced
```

### 2.3 Training Execution

```
Step 1: Dataset Preparation
├─ Gather approved training_pairs (status = approved)
├─ Format: Alpaca / ChatML / custom format
├─ Split: 90% train, 10% eval
└─ Upload to training environment

Step 2: Environment Setup
├─ Platform: Kaggle (free T4) or Vast.ai (on-demand GPU)
├─ Base model: qwen2.5-7b-instruct
├─ QLoRA config:
│  ├── r = 64
│  ├── alpha = 128
│  ├── target_modules = ["q_proj", "k_proj", "v_proj", "o_proj"]
│  ├── dropout = 0.05
│  └── bias = "none"
├─ Training config:
│  ├── learning_rate = 2e-4
│  ├── batch_size = 4
│  ├── gradient_accumulation = 4
│  ├── epochs = 3
│  ├── warmup_steps = 100
│  └── logging_steps = 10
└─ Start training job

Step 3: Monitoring
├─ Watch train_loss curve
├─ Watch eval_loss curve
├─ Detect overfitting (eval_loss rising while train_loss falling)
└─ Early stopping if eval_loss plateaus

Step 4: Evaluation
├─ Generate on eval set
├─ Compute BLEU score
├─ Compute ROUGE-L score
├─ Human evaluation (20 random samples)
└─ Pass threshold: BLEU > 0.45, ROUGE-L > 0.50

Step 5: A/B Testing
├─ Deploy new adapter to staging
├─ Run 50/50 split for 24 hours
├─ Compare metrics:
│  ├── Response quality (CQF)
│  ├── User satisfaction (thumbs ratio)
│  ├── Error rate
│  └── Response time
└─ Decide: deploy new, keep old, or retrain

Step 6: Deployment
├─ If new wins: deploy to production
├─ Backup old adapter
├─ Update model version in config
├─ Announce in changelog
└─ Monitor for 48 hours post-deploy
```

---

## 3. HEALTH MONITORING METHOD (Syifa)

### 3.1 Metrics Collection

```
Every 60 seconds:
├─ CPU usage (os.cpu_percent())
├─ Memory usage (psutil.virtual_memory())
├─ Disk usage (psutil.disk_usage('/'))
├─ Response time (middleware tracking)
├─ Error rate (exception middleware)
├─ Queue length (Celery inspect)
├─ Ollama status (HTTP ping)
├─ Database connections (psql active count)
└─ Redis memory (INFO memory)
```

### 3.2 Health Levels

| Level | CPU | Memory | Disk | Response Time | Error Rate | Action |
|-------|-----|--------|------|---------------|------------|--------|
| **HEALTHY** | <70% | <70% | <80% | <1000ms | <1% | None |
| **DEGRADED** | 70-85% | 70-85% | 80-90% | 1000-3000ms | 1-5% | Reduce batch, CPU fallback |
| **SICK** | 85-95% | 85-95% | 90-95% | 3000-5000ms | 5-10% | Restart service, clear cache |
| **CRITICAL** | >95% | >95% | >95% | >5000ms | >10% | Full restart, alert, safe mode |

### 3.3 Auto-Heal Actions

```
DEGRADED:
├─ Reduce Ollama batch size from 512 to 256
├─ Switch image generation to CPU mode (FLUX-schnell)
├─ Pause non-essential background jobs
└─ Log warning

SICK:
├─ Restart Ollama service
├─ Clear Redis cache
├─ Switch to backup model (smaller, faster)
├─ Pause all background tasks
├─ Send alert to admin
└─ Log incident

CRITICAL:
├─ Restart all services
├─ Enter safe mode (chat only, no generation)
├─ Send URGENT alert to admin (SMS + email)
├─ Write incident report
├─ Request manual intervention
└─ Log critical incident
```

---

## 4. EPISTEMIC LABELING METHOD

### 4.1 Label Assignment Rules

| Content Type | Label | Rule |
|--------------|-------|------|
| Historical date | [FACT] | Matches multiple verified sources |
| Quranic verse | [FACT] | Exact match with corpus |
| Scientific claim | [FACT] | Matches peer-reviewed source |
| Statistical data | [FACT] | Has source citation |
| Theological opinion | [OPINION] | Scholar's interpretation |
| Political analysis | [OPINION] | Reasoned position |
| Aesthetic judgment | [OPINION] | "Beautiful", "ugly" |
| Prediction | [CLAIM] | "Will increase by 30%" |
| Hypothesis | [CLAIM] | "May be caused by..." |
| Uncertain info | [UNKNOWN] | "I don't have data on..." |
| AI image | [CREATED] | Generated by SIDIX |
| AI code | [CREATED] | Generated by SIDIX |
| Referenced concept | [REFERENCED] | "Based on Bauhaus..." |
| Inspired style | [INSPIRED] | "Inspired by Nike..." |
| Data-driven claim | [DATA-DRIVEN] | "Q1 data shows..." |

### 4.2 Implementation

```python
class EpistemicLabeler:
    def label(self, text: str, sources: list) -> list:
        labels = []
        
        # Check for factual claims
        if self._has_verified_sources(text, sources):
            labels.append("FACT")
        
        # Check for opinions
        if self._has_opinion_markers(text):
            labels.append("OPINION")
        
        # Check for uncertainty
        if self._has_uncertainty_markers(text):
            labels.append("UNKNOWN")
        
        # Check for generated content
        if self._is_generated(text):
            labels.append("CREATED")
        
        return labels
    
    def _has_verified_sources(self, text, sources):
        # Check if sources exist and are TIER_1 or TIER_2
        return any(s.tier <= 2 for s in sources)
    
    def _has_opinion_markers(self, text):
        markers = ["saya pikir", "menurut saya", "my opinion", "I believe",
                   "sebaiknya", "disarankan", "recommended"]
        return any(m in text.lower() for m in markers)
    
    def _has_uncertainty_markers(self, text):
        markers = ["tidak yakin", "belum pasti", "mungkin", "perhaps",
                   "saya tidak tahu", "I don't know", "not sure"]
        return any(m in text.lower() for m in markers)
```

---

## 5. SANAD CHAIN METHOD

### 5.1 Chain Construction

```
Every piece of knowledge has a chain:

Knowledge: "Kereta Api Indonesia was founded in 1945"
├─ Source: Wikipedia article "Kereta Api Indonesia"
├─ Source URL: https://en.wikipedia.org/wiki/Kereta_Api_Indonesia
├─ Source Tier: TIER_2 (single credible source)
├─ Extraction Date: 2026-04-25
├─ Last Verified: 2026-04-25
├─ Sanad Length: 1 (direct source)
└─ Confidence: 0.85

Knowledge: "Prayer times for Jakarta today"
├─ Source: Al-Adhan API (Islamic prayer times)
├─ Source URL: https://aladhan.com/prayer-times-api
├─ Source Tier: TIER_1 (authoritative Islamic source)
├─ Extraction Date: 2026-04-25
├─ Last Verified: 2026-04-25 (daily refresh)
├─ Sanad Length: 1 (direct API)
└─ Confidence: 0.99

Knowledge: "AI will replace 50% of creative jobs by 2030"
├─ Source: McKinsey Report 2025
├─ Source URL: https://mckinsey.com/...
├─ Source Tier: TIER_2 (research report)
├─ Extraction Date: 2026-01-15
├─ Last Verified: 2026-04-25
├─ Sanad Length: 1
└─ Confidence: 0.70 (prediction, not fact)
└─ Label: [CLAIM]
```

### 5.2 Chain Verification

```python
class SanadVerifier:
    def verify(self, knowledge_node: dict) -> dict:
        """
        1. Check if source still exists (HTTP 200)
        2. Check if content still matches (hash comparison)
        3. Check if newer sources contradict (Naskh handler)
        4. Update confidence score
        5. Return verification result
        """
        pass
```

---

*Methods are the DNA of SIDIX. They must be followed precisely, improved continuously, and documented thoroughly.*
