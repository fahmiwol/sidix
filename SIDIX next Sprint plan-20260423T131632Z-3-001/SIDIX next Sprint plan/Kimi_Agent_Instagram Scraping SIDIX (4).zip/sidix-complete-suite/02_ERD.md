# 02 — ENTITY RELATIONSHIP DIAGRAM (ERD)
## Complete Database Schema for SIDIX Agency OS

**Version:** 1.0
**Date:** 2026-04-25
**Database:** PostgreSQL (primary) + Neo4j (Knowledge Graph)
**ORM:** SQLModel / SQLAlchemy

---

## 1. OVERVIEW

SIDIX menggunakan **hybrid database architecture**:
- **PostgreSQL** — structured data (users, clients, campaigns, assets, analytics)
- **Neo4j** — Knowledge Graph (brand entities, relationships, creative concepts)
- **Redis** — Cache + Session + Queue
- **MinIO/S3** — Binary asset storage (images, videos, audio)

---

## 2. POSTGRESQL SCHEMA

### 2.1 Agency Core Tables

```sql
-- ============================================================
-- 1. AGENCY / ORGANIZATION
-- ============================================================
CREATE TABLE agencies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,                    -- "Tiranyx"
    slug VARCHAR(100) UNIQUE NOT NULL,             -- "tiranyx"
    description TEXT,
    logo_url VARCHAR(500),
    website VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    settings JSONB DEFAULT '{}'                    -- agency-level config
);

-- ============================================================
-- 2. USERS (Agency Team Members)
-- ============================================================
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agency_id UUID REFERENCES agencies(id),
    email VARCHAR(255) UNIQUE NOT NULL,
    username VARCHAR(100) UNIQUE NOT NULL,
    full_name VARCHAR(255),
    avatar_url VARCHAR(500),
    role VARCHAR(50) NOT NULL,                   -- admin, creative, strategist, developer, client_viewer
    persona_default VARCHAR(50),                   -- AYMAN, ABOO, OOMAR, UTZ, ALEY
    permissions JSONB DEFAULT '[]',                  -- granular permissions
    last_login TIMESTAMP,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- 3. CLIENTS (BRANCH SYSTEM)
-- ============================================================
CREATE TABLE clients (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agency_id UUID REFERENCES agencies(id),
    name VARCHAR(255) NOT NULL,                    -- "PT Kereta Api Indonesia"
    slug VARCHAR(100) NOT NULL,                    -- "kai"
    industry VARCHAR(100),                         -- "transportation"
    website VARCHAR(255),
    description TEXT,
    status VARCHAR(50) DEFAULT 'active',           -- active, paused, archived
    
    -- Brand Identity (auto-extracted or manually defined)
    brand_colors JSONB DEFAULT '[]',               -- [{"name": "Primary", "hex": "#0033A0"}]
    brand_fonts JSONB DEFAULT '[]',                -- [{"role": "heading", "family": "Montserrat"}]
    brand_voice TEXT,                              -- tone description
    brand_logo_url VARCHAR(500),
    
    -- Contact
    contact_name VARCHAR(255),
    contact_email VARCHAR(255),
    contact_phone VARCHAR(50),
    
    -- Billing
    plan VARCHAR(50) DEFAULT 'pilot',              -- pilot, standard, premium
    monthly_budget DECIMAL(12,2),                  -- in IDR
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(agency_id, slug)
);

-- ============================================================
-- 4. BRAND GUIDELINES (Versioned)
-- ============================================================
CREATE TABLE brand_guidelines (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID REFERENCES clients(id),
    version INTEGER NOT NULL DEFAULT 1,
    
    -- Logo specs
    logo_primary_url VARCHAR(500),
    logo_secondary_url VARCHAR(500),
    logo_favicon_url VARCHAR(500),
    logo_usage_rules TEXT,
    
    -- Color system
    color_primary VARCHAR(7),
    color_secondary VARCHAR(7),
    color_accent VARCHAR(7),
    color_text VARCHAR(7),
    color_background VARCHAR(7),
    color_palette JSONB DEFAULT '[]',
    
    -- Typography
    font_heading VARCHAR(100),
    font_body VARCHAR(100),
    font_accent VARCHAR(100),
    typography_scale JSONB DEFAULT '{}',
    
    -- Voice & Tone
    voice_description TEXT,
    tone_keywords JSONB DEFAULT '[]',              -- ["trustworthy", "warm", "professional"]
    do_rules TEXT,
    dont_rules TEXT,
    
    -- Imagery
    imagery_style TEXT,                            -- "warm photography, nostalgic tones"
    imagery_examples JSONB DEFAULT '[]',
    
    -- Export formats
    pdf_url VARCHAR(500),
    web_url VARCHAR(500),
    figma_url VARCHAR(500),
    
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_current BOOLEAN DEFAULT true,
    
    UNIQUE(client_id, version)
);

-- ============================================================
-- 5. CAMPAIGNS
-- ============================================================
CREATE TABLE campaigns (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID REFERENCES clients(id),
    agency_id UUID REFERENCES agencies(id),
    
    name VARCHAR(255) NOT NULL,                    -- "Ramadan 2026 - Pulang"
    slug VARCHAR(100) NOT NULL,
    description TEXT,
    
    -- Campaign specs
    objective VARCHAR(100),                        -- brand_awareness, conversion, engagement, lead_gen
    target_audience TEXT,                          -- "Gen Z, 18-25, urban Indonesia"
    budget DECIMAL(12,2),
    currency VARCHAR(3) DEFAULT 'IDR',
    
    -- Timeline
    start_date DATE,
    end_date DATE,
    status VARCHAR(50) DEFAULT 'draft',            -- draft, approved, active, completed, archived
    
    -- Creative direction (generated by AYMAN)
    creative_concept TEXT,
    visual_direction TEXT,
    messaging_framework TEXT,
    
    -- Performance
    kpi_targets JSONB DEFAULT '{}',                -- {"reach": 1000000, "engagement": 8.5}
    actual_performance JSONB DEFAULT '{}',
    
    -- Multi-agent workflow
    assigned_agents JSONB DEFAULT '[]',            -- ["AYMAN", "UTZ", "ALEY"]
    workflow_status VARCHAR(50) DEFAULT 'pending', -- pending, in_progress, review, approved, delivered
    
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(client_id, slug)
);

-- ============================================================
-- 6. ASSETS (Creative Output Library)
-- ============================================================
CREATE TABLE assets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID REFERENCES clients(id),
    campaign_id UUID REFERENCES campaigns(id),
    
    name VARCHAR(255) NOT NULL,
    type VARCHAR(50) NOT NULL,                     -- image, video, audio, document, code, design
    format VARCHAR(50),                            -- png, mp4, mp3, pdf, py, figma
    
    -- Storage
    storage_path VARCHAR(500),                     -- MinIO/S3 path
    public_url VARCHAR(500),                       -- CDN URL
    thumbnail_url VARCHAR(500),
    
    -- Metadata
    dimensions VARCHAR(50),                        -- "1080x1080" for images
    duration INTEGER,                              -- seconds for video/audio
    file_size_bytes BIGINT,
    
    -- AI Generation metadata
    ai_model VARCHAR(100),                         -- "FLUX.1-dev", "CogVideoX-5B"
    ai_prompt TEXT,                                -- the prompt used
    ai_seed INTEGER,
    ai_negative_prompt TEXT,
    ai_params JSONB DEFAULT '{}',                  -- {"steps": 50, "guidance": 7.5}
    
    -- Quality
    cqf_score DECIMAL(3,1),                        -- 0.0 to 10.0
    maqashid_pass BOOLEAN DEFAULT true,
    
    -- Approval workflow
    status VARCHAR(50) DEFAULT 'draft',            -- draft, review, revision, approved, rejected
    revision_count INTEGER DEFAULT 0,
    approved_by UUID REFERENCES users(id),
    approved_at TIMESTAMP,
    
    -- Usage
    usage_count INTEGER DEFAULT 0,                 -- how many times used in posts
    last_used_at TIMESTAMP,
    
    -- Tags
    tags JSONB DEFAULT '[]',
    
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- 7. CONTENT CALENDAR (Posts & Schedule)
-- ============================================================
CREATE TABLE content_calendar (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID REFERENCES clients(id),
    campaign_id UUID REFERENCES campaigns(id),
    asset_id UUID REFERENCES assets(id),
    
    -- Content
    platform VARCHAR(50) NOT NULL,                 -- instagram, tiktok, twitter, facebook, linkedin, youtube
    content_type VARCHAR(50),                      -- feed, story, reels, short, tweet, post
    caption TEXT,
    hashtags JSONB DEFAULT '[]',
    mentions JSONB DEFAULT '[]',
    
    -- Schedule
    scheduled_at TIMESTAMP,
    timezone VARCHAR(50) DEFAULT 'Asia/Jakarta',
    
    -- Status
    status VARCHAR(50) DEFAULT 'draft',            -- draft, scheduled, published, failed, archived
    published_at TIMESTAMP,
    published_url VARCHAR(500),                    -- link to live post
    
    -- Performance (after publish)
    metrics JSONB DEFAULT '{}',                    -- {"reach": 5000, "likes": 300, "comments": 45}
    
    -- AI metadata
    ai_generated BOOLEAN DEFAULT false,
    ai_persona VARCHAR(50),                        -- ALEY, UTZ, etc.
    
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- 8. ANALYTICS (Cross-Platform Data)
-- ============================================================
CREATE TABLE analytics_daily (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID REFERENCES clients(id),
    date DATE NOT NULL,
    platform VARCHAR(50) NOT NULL,
    
    -- Audience
    followers INTEGER DEFAULT 0,
    followers_change INTEGER DEFAULT 0,
    
    -- Content performance
    posts_count INTEGER DEFAULT 0,
    impressions BIGINT DEFAULT 0,
    reach BIGINT DEFAULT 0,
    profile_views INTEGER DEFAULT 0,
    
    -- Engagement
    likes INTEGER DEFAULT 0,
    comments INTEGER DEFAULT 0,
    shares INTEGER DEFAULT 0,
    saves INTEGER DEFAULT 0,
    engagement_rate DECIMAL(5,2),                  -- percentage
    
    -- Video-specific
    video_views INTEGER DEFAULT 0,
    avg_watch_time DECIMAL(6,2),                   -- seconds
    
    -- Traffic
    website_clicks INTEGER DEFAULT 0,
    email_clicks INTEGER DEFAULT 0,
    
    -- Ads
    ad_spend DECIMAL(12,2) DEFAULT 0,
    ad_impressions BIGINT DEFAULT 0,
    ad_clicks INTEGER DEFAULT 0,
    ad_ctr DECIMAL(5,2),
    ad_cpc DECIMAL(10,2),
    ad_conversions INTEGER DEFAULT 0,
    ad_roas DECIMAL(5,2),
    
    -- AI insight (auto-generated)
    ai_insight TEXT,
    ai_recommendation TEXT,
    
    fetched_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(client_id, date, platform)
);

-- ============================================================
-- 9. COMPETITOR TRACKING
-- ============================================================
CREATE TABLE competitors (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID REFERENCES clients(id),
    
    name VARCHAR(255) NOT NULL,
    website VARCHAR(255),
    social_handles JSONB DEFAULT '{}',             -- {"instagram": "@rival", "tiktok": "@rival"}
    industry VARCHAR(100),
    
    -- Tracking config
    platforms_tracked JSONB DEFAULT '[]',            -- ["instagram", "tiktok"]
    track_frequency VARCHAR(50) DEFAULT 'daily',   -- hourly, daily, weekly
    
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE competitor_posts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    competitor_id UUID REFERENCES competitors(id),
    
    platform VARCHAR(50) NOT NULL,
    post_url VARCHAR(500),
    content_type VARCHAR(50),
    caption TEXT,
    
    -- Metrics (scraped)
    likes INTEGER,
    comments INTEGER,
    shares INTEGER,
    views INTEGER,
    posted_at TIMESTAMP,
    scraped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- AI analysis
    sentiment VARCHAR(50),                           -- positive, neutral, negative
    topics JSONB DEFAULT '[]',
    engagement_rate DECIMAL(5,2)
);

-- ============================================================
-- 10. TRENDS (Scraped & Analyzed)
-- ============================================================
CREATE TABLE trends (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    keyword VARCHAR(255) NOT NULL,
    category VARCHAR(100),                           -- tech, design, marketing, culture, viral
    source VARCHAR(100),                             -- google_trends, twitter, tiktok, reddit
    
    -- Metrics
    volume_score INTEGER,                            -- 0-100
    velocity VARCHAR(50),                            -- slow_burn, rising, fast_rising, peaked, declining
    sentiment VARCHAR(50),                           -- positive, neutral, negative, controversial
    
    -- Time series
    first_seen TIMESTAMP,
    peak_at TIMESTAMP,
    
    -- Content generated from this trend
    content_generated JSONB DEFAULT '[]',            -- [asset_id, asset_id]
    
    -- AI analysis
    ai_summary TEXT,
    ai_opportunity TEXT,
    
    scraped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- 11. CONVERSATIONS (Chat History per Client)
-- ============================================================
CREATE TABLE conversations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID REFERENCES clients(id),
    user_id UUID REFERENCES users(id),
    
    title VARCHAR(255),                            -- auto-generated from first message
    
    -- Agent context
    active_persona VARCHAR(50),                      -- AYMAN, ABOO, etc.
    active_tools JSONB DEFAULT '[]',               -- ["image_editor", "code_gen"]
    
    -- Settings
    mode VARCHAR(50) DEFAULT 'chat',               -- chat, creative, analysis, code
    maqashid_mode VARCHAR(50) DEFAULT 'GENERAL',     -- CREATIVE, ACADEMIC, IJTIHAD, GENERAL
    
    -- Stats
    message_count INTEGER DEFAULT 0,
    last_message_at TIMESTAMP,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id UUID REFERENCES conversations(id),
    
    role VARCHAR(50) NOT NULL,                     -- user, assistant, system, tool
    content TEXT NOT NULL,
    
    -- Epistemic labels
    epistemic_labels JSONB DEFAULT '[]',           -- ["FACT", "OPINION"]
    cqf_score DECIMAL(3,1),
    
    -- Tool usage
    tool_calls JSONB DEFAULT '[]',                   -- [{"name": "image_gen", "args": {}}]
    tool_results JSONB DEFAULT '[]',
    
    -- Agent info
    persona_used VARCHAR(50),
    knowledge_layers JSONB DEFAULT '[]',            -- ["parametric", "dynamic"]
    
    -- Learning
    user_feedback VARCHAR(50),                       -- thumbs_up, thumbs_down, none
    captured_for_training BOOLEAN DEFAULT false,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- 12. KNOWLEDGE GRAPH ENTRIES (Bridge to Neo4j)
-- ============================================================
CREATE TABLE kg_nodes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID REFERENCES clients(id),         -- null = shared knowledge
    
    label VARCHAR(100) NOT NULL,                   -- Person, Concept, Brand, Product, Trend
    name VARCHAR(255) NOT NULL,
    properties JSONB DEFAULT '{}',
    
    source VARCHAR(100),                           -- web_crawl, user_input, ai_generated
    confidence DECIMAL(3,2) DEFAULT 1.0,           -- 0.0 to 1.0
    
    -- Neo4j reference
    neo4j_node_id VARCHAR(100),
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE kg_relationships (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    source_node_id UUID REFERENCES kg_nodes(id),
    target_node_id UUID REFERENCES kg_nodes(id),
    relationship_type VARCHAR(100) NOT NULL,         -- KNOWS, CREATED, PART_OF, COMPETES_WITH
    properties JSONB DEFAULT '{}',
    
    neo4j_rel_id VARCHAR(100),
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- 13. TRAINING DATASET (Jariyah Learning)
-- ============================================================
CREATE TABLE training_pairs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    instruction TEXT NOT NULL,
    response TEXT NOT NULL,
    
    -- Metadata
    source VARCHAR(100),                           -- web_crawl, user_chat, manual_curation
    category VARCHAR(100),                         -- general, creative, analysis, code, religious
    language VARCHAR(10) DEFAULT 'id',             -- id, en, ar, ms, tl, hi
    
    -- Quality
    cqf_score DECIMAL(3,1),
    cqf_criteria JSONB DEFAULT '{}',               -- detailed breakdown
    
    -- Status
    status VARCHAR(50) DEFAULT 'pending',          -- pending, approved, rejected, trained
    reviewed_by UUID REFERENCES users(id),
    reviewed_at TIMESTAMP,
    
    -- Usage
    used_in_training BOOLEAN DEFAULT false,
    training_run_id UUID,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- 14. TRAINING RUNS (QLoRA Retrain Tracking)
-- ============================================================
CREATE TABLE training_runs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    name VARCHAR(255),                             -- "jariyah-run-2026-04-25"
    base_model VARCHAR(100),                       -- "qwen2.5-7b-instruct"
    
    -- Dataset
    dataset_size INTEGER,
    train_size INTEGER,
    eval_size INTEGER,
    
    -- Config
    lora_r INTEGER DEFAULT 64,
    lora_alpha INTEGER DEFAULT 128,
    learning_rate DECIMAL(10,8),
    epochs INTEGER,
    
    -- Results
    train_loss DECIMAL(10,6),
    eval_loss DECIMAL(10,6),
    eval_bleu DECIMAL(5,2),
    eval_rouge_l DECIMAL(5,2),
    
    -- Status
    status VARCHAR(50) DEFAULT 'queued',             -- queued, training, completed, failed
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    
    -- Artifact
    model_path VARCHAR(500),
    checkpoint_path VARCHAR(500),
    
    -- A/B test
    ab_test_result VARCHAR(50),                    -- new_better, old_better, tie
    deployed BOOLEAN DEFAULT false,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- 15. HEALTH & MONITORING (Qalb System)
-- ============================================================
CREATE TABLE health_checks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    component VARCHAR(100) NOT NULL,                 -- backend, ollama, database, disk, memory
    status VARCHAR(50) NOT NULL,                     -- healthy, degraded, sick, critical
    
    -- Metrics
    metric_value DECIMAL(10,2),
    metric_unit VARCHAR(50),                         -- percent, ms, mb, count
    threshold DECIMAL(10,2),
    
    -- Detail
    details JSONB DEFAULT '{}',
    
    -- Auto-heal
    auto_heal_attempted BOOLEAN DEFAULT false,
    auto_heal_action TEXT,
    auto_heal_result VARCHAR(50),                    -- success, failed, skipped
    
    checked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- 16. AUDIT LOG (Security & Compliance)
-- ============================================================
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    user_id UUID REFERENCES users(id),
    client_id UUID REFERENCES clients(id),
    
    action VARCHAR(100) NOT NULL,                  -- create, update, delete, generate, approve
    entity_type VARCHAR(100),                      -- campaign, asset, content_calendar
    entity_id UUID,
    
    old_values JSONB DEFAULT '{}',
    new_values JSONB DEFAULT '{}',
    
    ip_address INET,
    user_agent TEXT,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## 3. NEO4J KNOWLEDGE GRAPH SCHEMA

### 3.1 Node Types

```cypher
// Core Node Labels
(:Person {name, role, expertise, confidence})
(:Brand {name, industry, tone, audience, confidence})
(:Product {name, category, features, price_range, confidence})
(:Concept {name, domain, definition, source, confidence})
(:Trend {name, category, velocity, sentiment, confidence})
(:CreativeStyle {name, characteristics, examples, confidence})
(:Platform {name, type, audience_demo, best_practices})
(:CampaignConcept {name, theme, visual_direction, target_emotion})
(:Asset {name, type, tags, performance_score})

// Agency-Specific
(:Client {name, industry, budget_range, status})
(:Competitor {name, strengths, weaknesses, market_share})
(:Influencer {name, platform, followers, niche, engagement_rate})
```

### 3.2 Relationship Types

```cypher
// Brand Relationships
(:Brand)-[:HAS_VOICE]->(:Concept)
(:Brand)-[:TARGETS]->(:Person)
(:Brand)-[:COMPETES_WITH]->(:Brand)
(:Brand)-[:OWNS]->(:Product)

// Creative Relationships
(:CampaignConcept)-[:USES_STYLE]->(:CreativeStyle)
(:CampaignConcept)-[:TARGETS]->(:Person)
(:CampaignConcept)-[:ADDRESSES]->(:Trend)
(:Asset)-[:FOLLOWS]->(:CreativeStyle)
(:Asset)-[:GENERATED_FOR]->(:Brand)

// Knowledge Relationships
(:Concept)-[:RELATED_TO]->(:Concept)
(:Trend)-[:INFLUENCES]->(:Concept)
(:Person)-[:CREATED]->(:Asset)
(:Platform)-[:FAVORS]->(:CreativeStyle)

// Agency Relationships
(:Client)-[:HAS_BRAND]->(:Brand)
(:Client)-[:COMPETES_WITH]->(:Competitor)
(:Client)-[:CAMPAIGNED]->(:CampaignConcept)
```

### 3.3 Example Queries

```cypher
// Find all campaigns that use "nostalgic" style for "KAI"
MATCH (b:Brand {name: "KAI"})-[:CAMPAIGNED]->(c:CampaignConcept)
      -[:USES_STYLE]->(s:CreativeStyle {name: "nostalgic"})
RETURN c.name, c.theme

// Find trending topics related to "skincare" in Ramadan
MATCH (t:Trend)-[:RELATED_TO]->(c:Concept {name: "skincare"})
WHERE t.category = "culture" AND t.velocity IN ["rising", "fast_rising"]
RETURN t.name, t.velocity, t.sentiment
ORDER BY t.velocity_score DESC

// Find which creative style performs best for Gen Z
MATCH (a:Asset)-[:FOLLOWS]->(s:CreativeStyle)
WHERE a.target_audience CONTAINS "Gen Z"
RETURN s.name, avg(a.performance_score) as avg_score
ORDER BY avg_score DESC
```

---

## 4. REDIS SCHEMA (Cache & Session)

### 4.1 Key Patterns

```
# Sessions
session:{session_id} → JSON {user_id, agency_id, client_id, persona, expires}

# Rate Limiting
rate_limit:{user_id}:{action} → counter (expires 1 min)

# Cache
cache:query:{hash} → response JSON (expires 1 hour)
cache:asset:{asset_id} → asset metadata (expires 24 hours)
cache:trend:{date} → trend list (expires 6 hours)

# Queue
celery:task:{task_id} → task status
gen:queue:{type} → list of generation jobs

# Real-time
ws:{user_id} → WebSocket connection state
notifications:{user_id} → unread notification list

# Branch Context
branch:{client_id}:kg → serialized Knowledge Graph subset
branch:{client_id}:preferences → client preferences
branch:{client_id}:assets:recent → recent 50 asset IDs
```

---

## 5. MINIO/S3 BUCKET STRUCTURE

```
sidix-assets/
├── {agency_id}/
│   ├── {client_id}/
│   │   ├── images/
│   │   │   ├── raw/              # Original AI-generated images
│   │   │   ├── edited/           # Edited versions
│   │   │   └── thumbnails/       # 300x300 previews
│   │   ├── videos/
│   │   │   ├── raw/
│   │   │   ├── edited/
│   │   │   └── previews/         # 5-sec GIF previews
│   │   ├── audio/
│   │   │   ├── voice/            # TTS outputs
│   │   │   ├── music/            # MusicGen outputs
│   │   │   └── sfx/              # Sound effects
│   │   ├── documents/
│   │   │   ├── brand-guides/     # PDF brand guides
│   │   │   ├── reports/          # Analytics reports
│   │   │   └── briefs/           # Campaign briefs
│   │   └── code/
│   │       ├── exports/          # Exported projects
│   │       └── snippets/         # Code snippets
│   ├── shared/
│   │   ├── templates/            # Agency-wide templates
│   │   ├── stock/                # Shared stock assets
│   │   └── fonts/                # Licensed fonts
│   └── system/
│       ├── backups/              # Database backups
│       └── logs/                 # Application logs
```

---

## 6. INDEXING & PERFORMANCE

### 6.1 PostgreSQL Indexes

```sql
-- Users
CREATE INDEX idx_users_agency ON users(agency_id);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);

-- Clients
CREATE INDEX idx_clients_agency ON clients(agency_id);
CREATE INDEX idx_clients_status ON clients(status);
CREATE INDEX idx_clients_industry ON clients(industry);

-- Campaigns
CREATE INDEX idx_campaigns_client ON campaigns(client_id);
CREATE INDEX idx_campaigns_status ON campaigns(status);
CREATE INDEX idx_campaigns_dates ON campaigns(start_date, end_date);

-- Assets
CREATE INDEX idx_assets_client ON assets(client_id);
CREATE INDEX idx_assets_campaign ON assets(campaign_id);
CREATE INDEX idx_assets_type ON assets(type);
CREATE INDEX idx_assets_status ON assets(status);
CREATE INDEX idx_assets_tags ON assets USING GIN (tags);

-- Content Calendar
CREATE INDEX idx_calendar_client ON content_calendar(client_id);
CREATE INDEX idx_calendar_scheduled ON content_calendar(scheduled_at);
CREATE INDEX idx_calendar_status ON content_calendar(status);
CREATE INDEX idx_calendar_platform ON content_calendar(platform);

-- Analytics
CREATE INDEX idx_analytics_client_date ON analytics_daily(client_id, date);
CREATE INDEX idx_analytics_platform ON analytics_daily(platform);

-- Messages
CREATE INDEX idx_messages_conversation ON messages(conversation_id);
CREATE INDEX idx_messages_created ON messages(created_at);

-- Training
CREATE INDEX idx_training_status ON training_pairs(status);
CREATE INDEX idx_training_category ON training_pairs(category);
CREATE INDEX idx_training_cqf ON training_pairs(cqf_score);
```

### 6.2 Neo4j Indexes

```cypher
CREATE INDEX brand_name FOR (b:Brand) ON (b.name);
CREATE INDEX trend_keyword FOR (t:Trend) ON (t.keyword);
CREATE INDEX concept_name FOR (c:Concept) ON (c.name);
CREATE INDEX asset_tags FOR (a:Asset) ON (a.tags);
CREATE FULLTEXT INDEX content_search FOR (c:CampaignConcept) ON EACH [c.name, c.theme, c.description];
```

---

## 7. DATA FLOW DIAGRAM

```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│   USER INPUT   │────▶│   BACKEND    │────▶│   OLLAMA     │
│  (Chat/File)   │     │   FastAPI    │     │   (LLM)      │
└──────────────┘     └──────┬───────┘     └──────────────┘
                            │
           ┌────────────────┼────────────────┐
           │                │                │
           ▼                ▼                ▼
    ┌──────────┐     ┌──────────┐     ┌──────────┐
    │PostgreSQL│     │  Neo4j   │     │  Redis   │
    │ (Tables) │     │   (KG)   │     │ (Cache)  │
    └──────────┘     └──────────┘     └──────────┘
           │                │                │
           └────────────────┼────────────────┘
                            │
                            ▼
                    ┌──────────────┐
                    │    MinIO     │
                    │   (Assets)   │
                    └──────────────┘
                            │
                            ▼
                    ┌──────────────┐
                    │    USER      │
                    │   (Output)   │
                    └──────────────┘
```

---

## 8. MIGRATION STRATEGY

### 8.1 From Current SIDIX to Agency OS

```sql
-- Step 1: Create new tables (run as migration)
-- Step 2: Migrate existing data
INSERT INTO agencies (id, name, slug, description)
VALUES ('default-agency', 'Default Agency', 'default', 'Legacy agency');

-- Step 3: Create default client (legacy mode)
INSERT INTO clients (id, agency_id, name, slug, status)
VALUES ('default-client', 'default-agency', 'Legacy', 'legacy', 'active');

-- Step 4: Migrate existing conversations
-- conversations table exists → add client_id column, set to 'default-client'

-- Step 5: Enable branching
-- When user creates first real client, switch from legacy mode
```

---

*This ERD is the single source of truth for all database operations in SIDIX.*
*Any schema change must be reflected here and versioned via Alembic.*
