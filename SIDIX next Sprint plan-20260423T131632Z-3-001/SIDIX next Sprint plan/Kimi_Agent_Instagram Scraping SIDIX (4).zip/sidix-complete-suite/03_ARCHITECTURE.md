# 03 — SYSTEM ARCHITECTURE
## SIDIX Agency OS · Technical Blueprint · Data Flow · Deployment

**Version:** 1.0
**Date:** 2026-04-25
**Status:** IMPLEMENTATION BLUEPRINT

---

## 1. HIGH-LEVEL ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              CLIENT LAYER                                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │   Web App    │  │  Mobile App  │  │   Chrome     │  │   MCP        │          │
│  │  (React)     │  │(React Native)│  │  Extension   │  │  Plugin      │          │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘          │
│         │                 │                 │                 │                   │
│         └─────────────────┴─────────────────┴─────────────────┘                   │
│                              │                                                    │
│                              ▼                                                    │
│  ┌─────────────────────────────────────────────────────────────────────────────┐│
│  │                         API GATEWAY (Caddy)                                  ││
│  │  · SSL termination                                                           ││
│  │  · Rate limiting                                                             ││
│  │  · Request routing                                                           ││
│  │  · Static file serving                                                       ││
│  └─────────────────────────────────────────────────────────────────────────────┘│
│                              │                                                    │
└──────────────────────────────┼────────────────────────────────────────────────────┘
                               │
┌──────────────────────────────┼────────────────────────────────────────────────────┐
│                              ▼                                                    │
│  ┌─────────────────────────────────────────────────────────────────────────────┐│
│  │                      APPLICATION LAYER (FastAPI)                             ││
│  │                                                                              ││
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐         ││
│  │  │   REST API  │  │  WebSocket  │  │   MCP API   │  │   Webhook   │         ││
│  │  │   (HTTP)    │  │  (Real-time)│  │  (Server)   │  │  (External) │         ││
│  │  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘         ││
│  │         │                │                │                │                 ││
│  │         └────────────────┴────────────────┴────────────────┘                 ││
│  │                          │                                                   ││
│  │  ┌───────────────────────▼───────────────────────────────────────────────┐    ││
│  │  │                    CORE SERVICES                                       │    ││
│  │  │  ┌────────────┐  ┌────────────┐  ┌────────────┐  ┌────────────┐     │    ││
│  │  │  │   Brain    │  │   Agency   │  │  Creative  │  │  Generative│     │    ││
│  │  │  │ (Jiwa 7)   │  │    OS      │  │   Suite    │  │   Models   │     │    ││
│  │  │  └────────────┘  └────────────┘  └────────────┘  └────────────┘     │    ││
│  │  └───────────────────────────────────────────────────────────────────────┘    ││
│  │                                                                              ││
│  └─────────────────────────────────────────────────────────────────────────────┘│
│                              │                                                    │
│  ┌───────────────────────────▼────────────────────────────────────────────────────┐
│  │                      SERVICE LAYER                                              │
│  │                                                                              │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │  │    RAG /     │  │   Trend      │  │   MCP        │  │   Auth /     │       │
│  │  │    Corpus    │  │   Scanner    │  │   Server     │  │   Security   │       │
│  │  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘       │
│  │                                                                              │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │  │   Asset      │  │   Report     │  │   Scheduler  │  │   Notification│      │
│  │  │   Manager    │  │   Generator  │  │   (Calendar) │  │   (Email/WS) │       │
│  │  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘       │
│  │                                                                              │
│  └───────────────────────────────────────────────────────────────────────────────┘
│                              │                                                    │
│  ┌───────────────────────────▼────────────────────────────────────────────────────┐
│  │                      DATA LAYER                                                   │
│  │                                                                              │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐         │
│  │  │  PostgreSQL  │  │    Neo4j    │  │    Redis    │  │    MinIO     │         │
│  │  │  (Structured)│  │   (Graph KG) │  │   (Cache)   │  │   (Assets)  │         │
│  │  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘         │
│  │                                                                              │
│  └───────────────────────────────────────────────────────────────────────────────┘
│                              │                                                    │
│  ┌───────────────────────────▼────────────────────────────────────────────────────┐
│  │                      AI MODEL LAYER                                               │
│  │                                                                              │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐         │
│  │  │   Ollama     │  │   Ollama     │  │   Diffusers  │  │   AudioCraft │         │
│  │  │  Qwen3-14B   │  │ Qwen-Coder   │  │   FLUX.1     │  │  MusicGen    │         │
│  │  │  (Text)      │  │  (Code)      │  │  (Image)     │  │  (Music)     │         │
│  │  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘         │
│  │                                                                              │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐         │
│  │  │   Ollama     │  │   Piper      │  │   Whisper    │  │   CogVideoX  │         │
│  │  │  DeepSeek    │  │    TTS       │  │    STT       │  │   (Video)    │         │
│  │  │ (Reasoning)  │  │  (Voice)     │  │  (Transcribe)│  │              │         │
│  │  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘         │
│  │                                                                              │
│  │  ┌──────────────┐  ┌──────────────┐                                          │
│  │  │   TripoSR    │  │   ControlNet │                                          │
│  │  │   (3D)       │  │  (Control)   │                                          │
│  │  └──────────────┘  └──────────────┘                                          │
│  │                                                                              │
│  └───────────────────────────────────────────────────────────────────────────────┘
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. FOLDER STRUCTURE

```
sidix/
├── 📁 .github/
│   └── workflows/
│       ├── ci.yml                    # GitHub Actions CI
│       ├── deploy.yml                # Auto deploy to VPS
│       └── release.yml               # Release automation
│
├── 📁 alembic/                       # Database migrations
│   ├── versions/
│   └── env.py
│
├── 📁 apps/                          # Application modules
│   ├── __init__.py
│   ├── agency_os/                    # Agency Operating System
│   │   ├── __init__.py
│   │   ├── dashboard.py              # Agency dashboard API
│   │   ├── clients.py                # Client/branch management
│   │   ├── campaigns.py              # Campaign management
│   │   ├── calendar.py               # Content calendar
│   │   ├── analytics.py              # Analytics dashboard
│   │   └── notifications.py          # Notification system
│   │
│   ├── creative_suite/               # Built-in creative tools
│   │   ├── __init__.py
│   │   ├── image_editor/             # Image editor
│   │   │   ├── __init__.py
│   │   │   ├── canvas.py             # Canvas rendering
│   │   │   ├── layers.py             # Layer management
│   │   │   ├── tools.py              # Tool implementations
│   │   │   ├── ai_generate.py        # AI generation in editor
│   │   │   └── export.py             # Export multi-format
│   │   │
│   │   ├── video_editor/             # Video editor
│   │   │   ├── __init__.py
│   │   │   ├── timeline.py           # Timeline engine
│   │   │   ├── tracks.py             # Track management
│   │   │   ├── transitions.py        # Transition effects
│   │   │   ├── captions.py           # Auto-caption
│   │   │   └── export.py             # Video export
│   │   │
│   │   ├── voice_studio/             # Voice studio
│   │   │   ├── __init__.py
│   │   │   ├── recorder.py           # Browser recording
│   │   │   ├── tts.py                # Text-to-speech
│   │   │   ├── voice_clone.py        # Voice cloning
│   │   │   └── effects.py            # Audio effects
│   │   │
│   │   ├── brand_guidelines/         # Brand guidelines maker
│   │   │   ├── __init__.py
│   │   │   ├── extractor.py          # Auto-extract from web
│   │   │   ├── generator.py            # Generate guidelines
│   │   │   ├── mockup.py             # Mockup generator
│   │   │   └── export.py             # Export PDF/Web/Figma
│   │   │
│   │   └── shared/                   # Shared creative components
│   │       ├── components.py         # React components
│   │       ├── hooks.py              # Custom hooks
│   │       └── utils.py              # Utilities
│   │
│   ├── dashboard/                    # User dashboard (legacy)
│   ├── brain_qa/                     # Q&A brain module
│   └── image_gen/                    # Image generation (legacy)
│
├── 📁 brain/                         # AI Brain (7 Pillars + Core)
│   ├── __init__.py
│   ├── main.py                       # Entry point
│   ├── config.py                     # Configuration
│   │
│   ├── nafs/                         # Pilar 1: Self-Respond
│   │   ├── __init__.py
│   │   ├── response_orchestrator.py  # 3-layer knowledge fusion
│   │   ├── knowledge_router.py       # Topic routing
│   │   └── epistemic_labeler.py      # [FACT]/[OPINION]/[UNKNOWN]
│   │
│   ├── aql/                          # Pilar 2: Self-Learn
│   │   ├── __init__.py
│   │   ├── learning_loop.py          # Jariyah v3 real-time
│   │   ├── drift_detector.py         # Performance drift detection
│   │   └── feedback_processor.py       # 👍/👎 processing
│   │
│   ├── qalb/                         # Pilar 3: Self-Heal
│   │   ├── __init__.py
│   │   ├── health_monitor.py         # System health check
│   │   ├── auto_healer.py            # Auto-repair actions
│   │   └── alert_manager.py          # Alert dispatch
│   │
│   ├── ruh/                          # Pilar 4: Self-Improve
│   │   ├── __init__.py
│   │   ├── improvement_engine.py     # Weekly self-evaluation
│   │   └── action_planner.py         # Improvement action plan
│   │
│   ├── hayat/                        # Pilar 5: Self-Iterate
│   │   ├── __init__.py
│   │   ├── iteration_engine.py       # Generate-evaluate-refine
│   │   └── quality_gate.py           # CQF ≥ 8.0 check
│   │
│   ├── ilm/                          # Pilar 6: Self-Crawl
│   │   ├── __init__.py
│   │   ├── web_crawler.py            # Ethical web crawling
│   │   ├── document_processor.py     # PDF/DOCX processing
│   │   └── api_collector.py          # API data collection
│   │
│   ├── hikmah/                       # Pilar 7: Self-Train
│   │   ├── __init__.py
│   │   ├── retrain_pipeline.py       # QLoRA auto-retrain
│   │   ├── ab_tester.py              # A/B test new vs old
│   │   └── deploy_manager.py         # Deploy/rollback
│   │
│   ├── jiwa/                         # Master Orchestrator
│   │   ├── __init__.py
│   │   └── orchestrator.py           # Integrate 7 pillars
│   │
│   ├── raudah/                       # Multi-Agent Protocol
│   │   ├── __init__.py
│   │   ├── task_graph.py             # DAG task decomposition
│   │   ├── agent_pool.py             # Agent management
│   │   ├── consensus.py              # Consensus mechanism
│   │   └── collaborative_learning.py # Cross-agent learning
│   │
│   ├── multilingual/                 # Multilingual framework
│   │   ├── __init__.py
│   │   ├── script_detector.py        # Script detection
│   │   ├── language_detector.py      # 6-language detection
│   │   ├── typo_dictionaries.py      # 1150+ typo patterns
│   │   ├── universal_corrector.py    # Typo correction
│   │   ├── semantic_matcher.py       # Cross-lingual intent
│   │   ├── cultural_responder.py     # Cultural response
│   │   └── pipeline.py               # End-to-end pipeline
│   │
│   ├── persona/                      # Persona system
│   │   ├── __init__.py
│   │   ├── ayman.py                  # Creative Director
│   │   ├── aboo.py                   # Research Director
│   │   ├── oomar.py                  # Producer
│   │   ├── utz.py                    # Visual Artist
│   │   ├── aley.py                   # Communicator
│   │   └── persona_router.py         # Auto-select persona
│   │
│   ├── tools/                        # 35+ Tools
│   │   ├── __init__.py
│   │   ├── registry.py               # Tool registration
│   │   ├── code_sandbox.py           # Code execution
│   │   ├── code_validator.py         # Code validation
│   │   ├── code_analyze.py           # Code analysis
│   │   ├── search_web.py             # Web search
│   │   ├── search_docs.py            # Document search
│   │   ├── generate_image.py         # Image generation
│   │   ├── generate_video.py         # Video generation
│   │   ├── generate_audio.py         # Audio generation
│   │   ├── analyze_sentiment.py      # Sentiment analysis
│   │   ├── analyze_market.py         # Market analysis
│   │   ├── schedule_post.py          # Social scheduling
│   │   └── ... (20+ more tools)
│   │
│   ├── corpus/                       # Knowledge corpus
│   │   ├── ihos/                     # IHOS principles
│   │   ├── maqashid/                 # Maqashid filter rules
│   │   ├── brand_frameworks/           # Branding frameworks
│   │   ├── copy_formulas/            # Copywriting formulas
│   │   └── nusantara/                # Nusantara cultural knowledge
│   │
│   └── serve/                        # Serving layer
│       ├── __init__.py
│       ├── agent_react.py            # ReAct loop (legacy entry)
│       ├── api.py                    # FastAPI routes
│       ├── websocket.py              # WebSocket handler
│       └── middleware.py             # Auth, rate limit, CORS
│
├── 📁 database/                      # Database layer
│   ├── __init__.py
│   ├── connection.py                 # DB connection manager
│   ├── models.py                     # SQLModel definitions
│   ├── migrations/                   # Alembic migrations
│   └── seeders/                      # Initial data seeding
│
├── 📁 frontend/                      # Web UI (React)
│   ├── public/
│   ├── src/
│   │   ├── components/               # Reusable components
│   │   │   ├── sidebar/              # Sidebar navigation
│   │   │   ├── chat/                 # Chat interface
│   │   │   ├── image_editor/         # Image editor UI
│   │   │   ├── video_editor/         # Video editor UI
│   │   │   ├── voice_studio/         # Voice studio UI
│   │   │   ├── brand_guidelines/     # Brand guidelines UI
│   │   │   ├── analytics/            # Analytics dashboard
│   │   │   └── calendar/             # Content calendar
│   │   │
│   │   ├── pages/                    # Page components
│   │   │   ├── Dashboard.tsx
│   │   │   ├── Chat.tsx
│   │   │   ├── ClientWorkspace.tsx
│   │   │   ├── CampaignBuilder.tsx
│   │   │   ├── ImageEditor.tsx
│   │   │   ├── VideoEditor.tsx
│   │   │   ├── VoiceStudio.tsx
│   │   │   ├── BrandGuidelines.tsx
│   │   │   ├── Analytics.tsx
│   │   │   └── Calendar.tsx
│   │   │
│   │   ├── hooks/                    # Custom React hooks
│   │   ├── stores/                     # Zustand state stores
│   │   ├── services/                   # API service layer
│   │   ├── types/                      # TypeScript types
│   │   ├── utils/                      # Utilities
│   │   └── App.tsx                     # Root component
│   │
│   ├── package.json
│   └── vite.config.ts
│
├── 📁 scripts/                       # Utility scripts
│   ├── deploy.sh                     # Deploy script
│   ├── restart.sh                    # Quick restart
│   ├── health-check.sh               # Health monitor
│   ├── backup.sh                     # Backup script
│   ├── setup.sh                      # First-time setup
│   └── windows/                      # Windows batch scripts
│       ├── install-deps.bat
│       ├── start-sidix.bat
│       └── ...
│
├── 📁 docs/                          # Documentation
│   ├── README.md
│   ├── ARCHITECTURE.md
│   ├── API.md                        # API documentation
│   ├── DEPLOY.md                     # Deployment guide
│   ├── CONTRIBUTING.md
│   ├── SECURITY.md
│   └── CHANGELOG.md
│
├── 📁 tests/                         # Test suite
│   ├── unit/                         # Unit tests
│   ├── integration/                  # Integration tests
│   ├── e2e/                          # End-to-end tests
│   └── conftest.py                   # Pytest configuration
│
├── 📁 docker/                        # Docker configuration
│   ├── Dockerfile.backend
│   ├── Dockerfile.frontend
│   ├── docker-compose.yml
│   └── docker-compose.prod.yml
│
├── 📁 .env.sample                    # Environment variables template
├── 📁 .env                           # Actual environment (gitignored)
├── 📁 .gitignore
├── 📁 pyproject.toml                 # Python dependencies
├── 📁 uv.lock                        # uv lock file
├── 📁 package.json                   # Node dependencies (if any)
├── 📁 Makefile                     # Common commands
├── 📁 ecosystem.config.js            # PM2 configuration
└── 📁 Caddyfile                      # Reverse proxy config
```

---

## 3. TECH STACK DETAIL

### 3.1 Backend

| Component | Technology | Version | Purpose |
|-----------|-----------|---------|---------|
| Framework | FastAPI | 0.115+ | REST API + WebSocket |
| ORM | SQLModel | 0.0.22+ | PostgreSQL models |
| Migration | Alembic | 1.13+ | DB schema versioning |
| Graph DB | Neo4j Python Driver | 5.18+ | Knowledge Graph |
| Cache | Redis | 7.x | Session + Queue + Cache |
| Queue | Celery | 5.3+ | Background tasks |
| Broker | Redis + Celery | — | Task queue |
| Storage | MinIO | latest | S3-compatible asset storage |
| Auth | JWT + bcrypt | — | Authentication |
| Validation | Pydantic v2 | — | Request/response validation |
| Testing | pytest | 8.x | Test framework |
| Coverage | pytest-cov | — | Test coverage |
| Lint | ruff | — | Python linting |
| Format | black | — | Python formatting |

### 3.2 Frontend

| Component | Technology | Version | Purpose |
|-----------|-----------|---------|---------|
| Framework | React | 18.x | UI library |
| Language | TypeScript | 5.x | Type safety |
| Styling | Tailwind CSS | 3.4+ | Utility CSS |
| Components | shadcn/ui | latest | UI components |
| State | Zustand | 4.x | State management |
| Query | TanStack Query | 5.x | Server state |
| Router | React Router | 6.x | Client routing |
| Canvas | Fabric.js | 6.x | Image editor canvas |
| Video | Wavesurfer.js | 7.x | Audio waveform |
| Icons | Lucide React | latest | Icon library |
| Build | Vite | 5.x | Build tool |
| Test | Vitest | 1.x | Unit testing |

### 3.3 AI Models

| Model | Source | Purpose | VRAM Need |
|-------|--------|---------|-----------|
| Qwen3-14B | Ollama | Text, reasoning, analysis | 8-16GB |
| Qwen-Coder-14B | Ollama | Code generation | 8-16GB |
| DeepSeek-R1 | Ollama | Deep reasoning | 16GB |
| Qwen-Math-7B | Ollama | Math problems | 4-8GB |
| FLUX.1-dev | Diffusers | High-quality images | 16-24GB |
| FLUX.1-schnell | Diffusers | Fast images | 8-16GB |
| CogVideoX-5B | Diffusers | Video generation | 24GB |
| LTX-Video | Diffusers | Fast video | 12-16GB |
| TripoSR | Diffusers | 3D generation | 8GB |
| MusicGen | AudioCraft | Music generation | 8GB |
| AudioGen | AudioCraft | Sound effects | 8GB |
| Piper TTS | Local | Text-to-speech | CPU |
| XTTS v2 | Coqui | Voice cloning | 4GB |
| Whisper | OpenAI | Speech-to-text | 2-4GB |
| ControlNet | Diffusers | Image control | 4-8GB |
| IP-Adapter | Diffusers | Style transfer | 4GB |
| Real-ESRGAN | Local | Image upscaling | 2GB |
| AnimateDiff | Diffusers | Animation | 8-12GB |

### 3.4 Infrastructure

| Component | Technology | Purpose |
|-----------|-----------|---------|
| Container | Docker + Docker Compose | Containerization |
| Orchestration | PM2 | Process management |
| Reverse Proxy | Caddy | SSL + routing |
| Monitoring | PM2 + health-check.sh | System health |
| Logs | PM2 logs + file rotation | Log management |
| Backup | MinIO + scripts/backup.sh | Data backup |
| CI/CD | GitHub Actions | Automated testing + deploy |

---

## 4. DATA FLOW

### 4.1 User Chat Flow

```
User types message
    │
    ▼
[1] Multilingual Pipeline
    ├── Script Detector (Latin/Arabic/CJK)
    ├── Language Detector (id/en/ar/ms/tl/hi)
    ├── Typo Corrector (1150+ patterns)
    └── Semantic Matcher (cross-lingual intent)
    │
    ▼
[2] Intent Classification
    ├── Is this a creative request? → Route to Agent Mode
    ├── Is this a tool call? → Route to Tool Mode
    ├── Is this general chat? → Route to Chat Mode
    └── Is this agency-related? → Route to Agency OS
    │
    ▼
[3] Persona Selection
    ├── AYMAN → Creative/branding tasks
    ├── ABOO → Research/analysis tasks
    ├── OOMAR → Execution/delivery tasks
    ├── UTZ → Visual/design tasks
    └── ALEY → Communication/copy tasks
    │
    ▼
[4] Knowledge Layer Selection (Nafs)
    ├── Parametric 60% → General knowledge (LLM weights)
    ├── Dynamic 30% → Brand KG + project memory
    └── Static 10% → IHOS principles + frameworks
    │
    ▼
[5] Raudah Multi-Agent (if complex)
    ├── Task decomposition → DAG
    ├── Parallel agent execution
    ├── Consensus + synthesis
    └── Maqashid filter per output
    │
    ▼
[6] Tool Execution (if needed)
    ├── Image generation → FLUX
    ├── Code generation → Qwen-Coder
    ├── Web search → Serper/Bing API
    ├── Analysis → Python execution
    └── ... 35+ tools
    │
    ▼
[7] Quality Gate (Hayat)
    ├── CQF scoring (10 criteria)
    ├── Maqashid filter check
    ├── Epistemic labeling
    └── Max 3 iterations if score < 8.0
    │
    ▼
[8] Response Delivery
    ├── Format response (markdown)
    ├── Attach generated assets
    ├── Add epistemic labels
    └── Push to conversation history
    │
    ▼
[9] Learning Capture (Aql)
    ├── Score interaction quality
    ├── Extract knowledge nuggets
    ├── Update Knowledge Graph
    └── Queue for training dataset
```

### 4.2 Creative Generation Flow

```
User: "Generate hero image for KAI Ramadan campaign"
    │
    ▼
[1] Load Branch Context
    ├── client_id = "kai"
    ├── brand_colors = ["#0033A0", "#FF6600"]
    ├── brand_tone = "trustworthy, warm, national"
    ├── campaign = "Ramadan 2026 - Pulang"
    └── visual_direction = "warm gold, nostalgic, family"
    │
    ▼
[2] Build Prompt
    ├── Base: "professional photography, train station"
    ├── Brand: "Kereta Api Indonesia branding"
    ├── Campaign: "Ramadan homecoming theme"
    ├── Style: "warm golden hour, nostalgic, family reunion"
    ├── Technical: "8k, highly detailed, cinematic"
    └── Negative: "blurry, low quality, modern cold tones"
    │
    ▼
[3] Generate (FLUX.1-dev)
    ├── Load Nusantara LoRA (if available)
    ├── Run inference (50 steps, guidance 7.5)
    ├── Generate 5 variants
    └── Aesthetic scoring per variant
    │
    ▼
[4] Quality Gate
    ├── CQF visual quality score
    ├── Brand alignment check
    ├── Maqashid cultural check
    └── Select best 3 variants
    │
    ▼
[5] Store & Deliver
    ├── Save to MinIO: assets/kai/images/raw/hero-ramadan-01.png
    ├── Create thumbnail
    ├── Add to asset library
    └── Present to user in Image Editor
```

### 4.3 Auto-Learning Flow (Jariyah v3)

```
Every 5 minutes:
    │
    ▼
Check pending interactions to learn from
    │
    ▼
For each interaction with user_feedback or high quality:
    ├── Anonymize (remove PII)
    ├── Extract: (query, response, context, feedback)
    ├── Score with CQF
    ├── Categorize: (creative, analysis, code, general, religious)
    └── Store in training_pairs table
    │
    ▼
Every Sunday 03:00:
    ├── Review new training_pairs (approved only)
    ├── Check if drift detected (performance drop > 5%)
    ├── If drift OR dataset grew by >1000 pairs:
    │   ├── Trigger QLoRA retrain
    │   ├── Train on Vast.ai or local GPU
    │   ├── Evaluate vs current model
    │   └── A/B test (new vs old)
    ├── If A/B shows improvement:
    │   ├── Deploy new adapter
    │   └── Archive old adapter
    └── Log to training_runs table
```

---

## 5. API DESIGN

### 5.1 REST API Endpoints

```
# Authentication
POST   /api/v1/auth/login
POST   /api/v1/auth/register
POST   /api/v1/auth/refresh
DELETE /api/v1/auth/logout

# Agency
GET    /api/v1/agency
PUT    /api/v1/agency

# Clients (Branches)
GET    /api/v1/clients
POST   /api/v1/clients
GET    /api/v1/clients/{id}
PUT    /api/v1/clients/{id}
DELETE /api/v1/clients/{id}
POST   /api/v1/clients/{id}/switch  # Switch active branch

# Campaigns
GET    /api/v1/clients/{id}/campaigns
POST   /api/v1/clients/{id}/campaigns
GET    /api/v1/campaigns/{id}
PUT    /api/v1/campaigns/{id}
DELETE /api/v1/campaigns/{id}
POST   /api/v1/campaigns/{id}/generate  # Auto-generate campaign package

# Assets
GET    /api/v1/clients/{id}/assets
POST   /api/v1/clients/{id}/assets/upload
POST   /api/v1/clients/{id}/assets/generate  # AI generate
GET    /api/v1/assets/{id}
PUT    /api/v1/assets/{id}
DELETE /api/v1/assets/{id}
POST   /api/v1/assets/{id}/approve

# Content Calendar
GET    /api/v1/clients/{id}/calendar
POST   /api/v1/clients/{id}/calendar
PUT    /api/v1/calendar/{id}
DELETE /api/v1/calendar/{id}
POST   /api/v1/calendar/{id}/publish

# Analytics
GET    /api/v1/clients/{id}/analytics
GET    /api/v1/clients/{id}/analytics/dashboard
GET    /api/v1/clients/{id}/analytics/report

# Brand Guidelines
GET    /api/v1/clients/{id}/brand-guidelines
POST   /api/v1/clients/{id}/brand-guidelines
PUT    /api/v1/clients/{id}/brand-guidelines
POST   /api/v1/clients/{id}/brand-guidelines/extract  # Auto-extract from URL

# Chat / Conversations
GET    /api/v1/conversations
POST   /api/v1/conversations
GET    /api/v1/conversations/{id}
POST   /api/v1/conversations/{id}/messages
GET    /api/v1/conversations/{id}/messages

# AI Generation
POST   /api/v1/generate/image
POST   /api/v1/generate/video
POST   /api/v1/generate/audio
POST   /api/v1/generate/code
POST   /api/v1/generate/music

# Tools
POST   /api/v1/tools/{tool_name}/execute
GET    /api/v1/tools

# Health
GET    /health
GET    /health/detailed

# Admin
GET    /api/v1/admin/users
GET    /api/v1/admin/health
GET    /api/v1/admin/metrics
```

### 5.2 WebSocket Events

```javascript
// Client → Server
{
  "type": "chat.message",
  "conversation_id": "uuid",
  "content": "Buatkan campaign Ramadan",
  "persona": "AYMAN",
  "client_id": "kai"
}

{
  "type": "editor.action",
  "tool": "image_editor",
  "action": "generate",
  "params": {
    "prompt": "warm gold train station",
    "width": 1080,
    "height": 1080
  }
}

// Server → Client
{
  "type": "chat.stream",
  "conversation_id": "uuid",
  "chunk": "Sedang menganalisis brief...",
  "agent": "AYMAN",
  "status": "thinking"
}

{
  "type": "asset.generated",
  "asset_id": "uuid",
  "asset_type": "image",
  "preview_url": "https://cdn.sidix/.../thumb.png",
  "download_url": "https://cdn.sidix/.../image.png",
  "cqf_score": 8.5
}

{
  "type": "agent.thought",
  "agent": "ABOO",
  "thought": "Trend analysis: skincare Ramadan naik 45%",
  "tool_calls": ["search_web", "analyze_trend"]
}

{
  "type": "system.notification",
  "title": "Campaign Ready for Review",
  "message": "KAI Ramadan campaign siap direview",
  "link": "/campaigns/uuid"
}
```

---

## 6. SECURITY ARCHITECTURE

### 6.1 Authentication

```
┌─────────────────────────────────────────────┐
│           AUTH FLOW                          │
│                                              │
│  1. User login (email + password)           │
│     ↓                                        │
│  2. bcrypt verify password                   │
│     ↓                                        │
│  3. Generate JWT (access + refresh)          │
│     ↓                                        │
│  4. Store session in Redis                   │
│     ↓                                        │
│  5. Return JWT to client                     │
│     ↓                                        │
│  6. Client sends JWT in Authorization header│
│     ↓                                        │
│  7. FastAPI verifies JWT + checks Redis     │
│     ↓                                        │
│  8. Check user permissions for resource     │
└─────────────────────────────────────────────┘
```

### 6.2 Authorization

| Role | Permissions |
|------|-------------|
| **admin** | Full access to all clients and agency settings |
| **creative** | Create/edit campaigns, assets, content calendar |
| **strategist** | View analytics, create reports, competitor tracking |
| **developer** | Access code generation, API keys, webhook management |
| **client_viewer** | View-only access to specific client's data |

### 6.3 Data Isolation

```python
# Every database query must include client_id filter
def get_campaigns(user: User, client_id: UUID):
    # Verify user has access to this client
    if not user.can_access(client_id):
        raise Forbidden("No access to this client")
    
    # Query with client_id filter
    return db.query(Campaign).filter(
        Campaign.client_id == client_id
    ).all()
```

---

## 7. DEPLOYMENT ARCHITECTURE

### 7.1 Single VPS (Current)

```
VPS (4-8 vCPU, 32GB RAM, 200GB SSD)
├── Caddy (reverse proxy, SSL)
│   ├── sidixlab.com → frontend static
│   ├── api.sidixlab.com → FastAPI
│   └── ws.sidixlab.com → WebSocket
├── PM2
│   ├── sidix-backend (FastAPI, port 8765)
│   ├── sidix-frontend (Vite preview, port 3000)
│   ├── sidix-worker (Celery)
│   └── sidix-health (cron health check)
├── Docker Compose
│   ├── PostgreSQL (port 5432)
│   ├── Neo4j (port 7687)
│   ├── Redis (port 6379)
│   └── MinIO (port 9000)
└── Ollama (port 11434)
    ├── Qwen3-14B
    ├── Qwen-Coder-14B
    ├── DeepSeek-R1
    └── ... (models loaded on demand)
```

### 7.2 Scaled (Future)

```
Load Balancer (Caddy/HAProxy)
├── API Server 1 (FastAPI)
├── API Server 2 (FastAPI)
├── API Server N (FastAPI)
├── GPU Worker 1 (Image/Video generation)
├── GPU Worker 2 (Video/3D generation)
└── CPU Worker Pool (Celery tasks)

Shared Services:
├── PostgreSQL (managed/RDS)
├── Neo4j Cluster
├── Redis Cluster
└── MinIO Cluster
```

---

## 8. MONITORING & OBSERVABILITY

### 8.1 Health Checks

| Component | Check | Interval | Auto-heal |
|-----------|-------|----------|-----------|
| Backend API | HTTP /health | 1 min | Yes (restart) |
| Ollama | HTTP /api/tags | 2 min | Yes (restart) |
| PostgreSQL | pg_isready | 2 min | Alert only |
| Neo4j | Cypher query | 5 min | Alert only |
| Redis | PING | 1 min | Yes (restart) |
| MinIO | HTTP /minio/health/live | 2 min | Yes (restart) |
| Disk space | df | 5 min | Alert + cleanup |
| Memory | free | 1 min | Alert only |

### 8.2 Metrics

```python
# Prometheus metrics (optional)
from prometheus_client import Counter, Histogram, Gauge

requests_total = Counter('sidix_requests_total', 'Total requests', ['method', 'endpoint'])
request_duration = Histogram('sidix_request_duration_seconds', 'Request duration')
generations_total = Counter('sidix_generations_total', 'Content generations', ['type'])
active_users = Gauge('sidix_active_users', 'Currently active users')
queue_length = Gauge('sidix_queue_length', 'Background queue length')
```

---

## 9. ENVIRONMENT VARIABLES

```bash
# === APP ===
SIDIX_ENV=production                    # development | staging | production
SIDIX_DEBUG=false
SIDIX_SECRET_KEY=your-secret-key-here

# === DATABASE ===
DATABASE_URL=postgresql://sidix:sidix@localhost:5432/sidix
NEO4J_URI=bolt://localhost:7687
NEO4J_USER=neo4j
NEO4J_PASSWORD=your-neo4j-password
REDIS_URL=redis://localhost:6379/0

# === STORAGE ===
MINIO_ENDPOINT=localhost:9000
MINIO_ACCESS_KEY=minioadmin
MINIO_SECRET_KEY=minioadmin
MINIO_BUCKET=sidix-assets

# === AI MODELS ===
OLLAMA_HOST=http://localhost:11434
OLLAMA_DEFAULT_MODEL=qwen3:14b
OLLAMA_CODE_MODEL=qwen-coder:14b
OLLAMA_REASONING_MODEL=deepseek-r1:14b

# === AGENCY OS ===
SIDIX_AGENCY_MODE=true                  # Enable agency features
SIDIX_DEFAULT_AGENCY_ID=default-agency
SIDIX_MAX_CLIENTS_PER_AGENCY=50

# === MCP ===
SIDIX_MCP_ENABLED=false                 # Default OFF for security
SIDIX_MCP_HOST=localhost
SIDIX_MCP_PORT=8766

# === FEATURE FLAGS ===
SIDIX_IMAGE_GENERATION=true
SIDIX_VIDEO_GENERATION=false            # Enable when ready
SIDIX_VOICE_GENERATION=true
SIDIX_CODE_GENERATION=true
SIDIX_TREND_SCANNING=true
SIDIX_AUTO_LEARNING=true

# === EXTERNAL APIs (optional) ===
SERPER_API_KEY=                         # Web search
BING_API_KEY=                           # Web search
META_APP_ID=                            # Facebook/Instagram API
META_APP_SECRET=
TIKTOK_DEVELOPER_KEY=                   # TikTok API
```

---

*This architecture document is the single source of truth for all engineering decisions.*
*Any structural change must be discussed and documented here.*
