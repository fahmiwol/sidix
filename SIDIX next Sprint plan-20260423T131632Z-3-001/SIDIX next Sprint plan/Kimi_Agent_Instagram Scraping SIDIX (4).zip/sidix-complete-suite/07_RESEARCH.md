# 07 — RESEARCH DOCUMENT
## Competitor Analysis · Technology Trends · Market Intelligence

**Version:** 1.0
**Date:** 2026-04-25
**Classification:** STRATEGIC INTELLIGENCE

---

## 1. COMPETITOR ANALYSIS

### 1.1 AI Creative Tools Landscape

| Competitor | Type | Strengths | Weaknesses | SIDIX Advantage |
|------------|------|-----------|------------|-----------------|
| **Midjourney** | Image Gen | Quality, community | Cloud-only, $30/mo, no brand context | Self-hosted + Nusantara + brand-safe |
| **DALL-E 3** | Image Gen | Prompt adherence | Closed, API cost, censored | Open + self-hosted + no vendor lock |
| **Stable Diffusion** | Image Gen | Open source | Needs technical setup | Pre-configured + agency tools |
| **FLUX (Black Forest)** | Image Gen | Quality, open | Requires GPU | Integrated with full pipeline |
| **Runway Gen-2** | Video Gen | Quality | Cloud-only, expensive | Self-hosted + CogVideoX |
| **Pika Labs** | Video Gen | Ease of use | Limited control | Full editor + AI generation |
| **ElevenLabs** | Voice/TTS | Natural voice | Cloud-only, cost per char | Piper + XTTS self-hosted |
| **HeyGen** | Avatar/Video | Avatars | Cloud-only | Not yet targeted |
| **Canva** | Design Tool | Ease of use | Template-based, not AI-native | AI-generates from scratch |
| **Adobe Firefly** | Design AI | Integration | Cloud, Adobe ecosystem | Independent + Islamic-safe |
| **ChatGPT** | Chat/Gen | General knowledge | Not creative-focused, API cost | Creative agency + self-hosted |
| **Claude** | Chat/Gen | Long context | Cloud-only | Self-hosted + IHOS |
| **Kimi** | Chat/Agent | 1M context, agentic | Not self-hosted | Self-hosted + no lock-in |
| **Cursor** | Code AI | Code intelligence | IDE-only, subscription | Full-stack + self-hosted |
| **Replit** | Code/Deploy | Easy deploy | Limited scope | More comprehensive |
| **Hootsuite** | Social Mgmt | Scheduling | Not AI-native | AI-native generation |
| **Buffer** | Social Mgmt | Simple | Limited | Full creative suite |
| **Sprout Social** | Social Mgmt | Analytics | Expensive | Integrated analytics |
| **HubSpot** | Marketing | CRM + automation | Generic, not creative | AI creative + CRM |
| **Brandfolder** | Brand Mgmt | Organization | Not AI-powered | AI-powered brand extraction |

### 1.2 Open Source AI Landscape

| Project | Stars | Focus | What SIDIX Can Learn |
|---------|-------|-------|---------------------|
| **Ollama** | 80K+ | Local LLM | UX simplicity for model management |
| **LangChain** | 90K+ | LLM framework | Tool chaining patterns |
| **ComfyUI** | 50K+ | Stable Diffusion UI | Node-based editor approach |
| **InvokeAI** | 20K+ | Image generation | Canvas-based editing |
| **Text Generation WebUI** | 35K+ | LLM UI | Model switching interface |
| **Automatic1111** | 40K+ | SD WebUI | Extension system |
| **Audiocraft** | 20K+ | Music generation | MusicGen integration |
| **OpenVoice** | 15K+ | Voice cloning | XTTS alternative |
| **FaceFusion** | 15K+ | Face swapping | Not relevant (avoid deepfake) |
| **RVC** | 15K+ | Voice conversion | Voice tech patterns |

### 1.3 Indonesian AI Landscape

| Project | Creator | Focus | Status |
|---------|---------|-------|--------|
| **Kata.ai** | Indonesian company | Chatbot platform | Active, commercial |
| **Prosa.ai** | Indonesian company | NLP solutions | Active, commercial |
| **Bahasa.ai** | Indonesian company | Bahasa NLP | Active, limited |
| **IndoBERT** | Research | Bahasa language model | Academic |
| **IndoGPT** | Research | Bahasa GPT | Academic, limited |
| **SIDIX** | Fahmi/Tiranyx | Agency OS + Creative AI | **Unique position** |

**Observation:** No Indonesian project combines creative generation + agency workflow + self-hosting + Islamic values. SIDIX occupies a unique niche.

---

## 2. TECHNOLOGY TRENDS

### 2.1 Generative AI Trends (2026)

| Trend | Status | SIDIX Relevance | Action |
|-------|--------|-----------------|--------|
| **Multimodal models** (vision + text) | Rising | High — Qwen-VL integration | Research |
| **Diffusion models** getting faster | Rising | High — FLUX.1-schnell | Implement |
| **Video generation** improving rapidly | Rising | High — CogVideoX, LTX | Implement |
| **3D generation** from text/image | Emerging | Medium — TripoSR | Prototype |
| **Music generation** quality improving | Rising | Medium — MusicGen | Implement |
| **Voice cloning** getting accessible | Rising | Medium — XTTS, OpenVoice | Implement |
| **Small models** (< 7B) getting capable | Rising | High — edge deployment | Research |
| **Mixture of Experts (MoE)** | Rising | High — Qwen3-MoE | Future |
| **Speculative decoding** | Emerging | High — 2x speed boost | Future |
| **Quantization** (INT4/INT8) | Active | High — reduce VRAM | Implement |

### 2.2 Self-Hosted AI Trends

| Trend | Status | SIDIX Relevance |
|-------|--------|-----------------|
| **Local LLM** popularity rising | Strong | Core strength |
| **Privacy-first AI** demand | Strong | Core value |
| **Edge AI** (on-device inference) | Rising | Future (mobile app) |
| **Federated learning** | Emerging | Future (Jariyah-hub v2) |
| **Home AI labs** (RTX 4090 setups) | Growing | Target market |
| **Open source model** proliferation | Strong | Beneficial |

### 2.3 Agency Tech Trends

| Trend | Status | SIDIX Relevance |
|-------|--------|-----------------|
| **AI-assisted creativity** | Strong | Core offering |
| **Content at scale** | Strong | Key benefit |
| **Real-time collaboration** | Rising | Future feature |
| **Brand consistency AI** | Rising | Brand Guidelines tool |
| **Predictive analytics** | Rising | Analytics Dashboard |
| **Auto-optimization** | Emerging | A/B test auto-optimize |

---

## 3. MARKET ANALYSIS

### 3.1 TAM/SAM/SOM

| Market | Definition | Size (2026) |
|--------|-----------|-------------|
| **TAM** (Total Addressable) | Global creative software + AI tools | $50B+ |
| **SAM** (Serviceable Addressable) | SE Asia creative agencies + SMEs | $5B |
| **SOM** (Serviceable Obtainable) | Indonesia + Malaysia agencies + creators | $500M |

### 3.2 Target Segments

| Segment | Size | Pain Point | SIDIX Solution |
|---------|------|------------|----------------|
| **Digital Agencies** (Indonesia) | 1,000+ | Scaling content production | 10x output, consistent quality |
| **SMEs with social presence** | 100K+ | No budget for agency | Self-serve creative generation |
| **Content creators** | 50K+ | Burnout from daily content | Auto-generate 20-50 pieces/week |
| **Indie developers** | 10K+ | No design skills | Full-stack app + brand kit |
| **Islamic organizations** | 5K+ | Need culturally appropriate content | Maqashid filter + Islamic context |

### 3.3 Pricing Benchmarks

| Product | Pricing | SIDIX Comparison |
|---------|---------|------------------|
| Midjourney | $30-60/mo | SIDIX free (self-hosted) |
| ElevenLabs | $5-330/mo | SIDIX free (Piper/XTTS) |
| Runway | $15-95/mo | SIDIX free (CogVideoX) |
| Canva Pro | $13/mo | SIDIX more powerful |
| HubSpot | $45-800/mo | SIDIX creative-focused |
| Cursor | $20/mo | SIDIX full-stack + more |
| ChatGPT Plus | $20/mo | SIDIX self-hosted + creative |
| **SIDIX Cloud** (planned) | $29-99/mo | Managed hosting option |

---

## 4. REGULATORY & ETHICAL LANDSCAPE

### 4.1 AI Regulation Trends

| Region | Status | Impact on SIDIX |
|--------|--------|-----------------|
| **EU AI Act** | Active | Self-hosted = less regulatory burden |
| **US Executive Order** | Active | Focus on safety — IHOS helps |
| **Indonesia** | Drafting | Being local = easier compliance |
| **Islamic Ethics** | Cultural | IHOS provides framework |

### 4.2 Content Moderation Standards

| Platform | Standard | SIDIX Approach |
|----------|----------|----------------|
| Meta | Strict on nudity, violence | Maqashid filter enforces |
| TikTok | Community guidelines | Maqashid filter enforces |
| YouTube | Advertiser-friendly | Brand-safe by design |
| **SIDIX** | Islamic + universal ethics | IHOS + Maqashid built-in |

---

## 5. RESEARCH METHODOLOGY

### 5.1 How SIDIX Does Research

```
1. Web Scraping (ethical)
   ├── robots.txt check
   ├── public data only
   ├── rate limiting (1 req/sec)
   └── attribution in output

2. API Integration
   ├── Google Trends API
   ├── Social media APIs (with permission)
   ├── News APIs
   └── Academic APIs (arXiv, etc.)

3. Academic Research
   ├── arXiv paper tracking
   ├── Hugging Face model hub
   └── GitHub trending repos

4. Community Monitoring
   ├── Reddit (r/LocalLLaMA, r/StableDiffusion)
   ├── Discord communities
   └── X/Twitter discussions

5. Competitive Tracking
   ├── Competitor social media
   ├── Product Hunt launches
   └── GitHub releases
```

### 5.2 Research Schedule

| Frequency | Activity | Output |
|-----------|----------|--------|
| Daily | Trend scan | Trend brief to users |
| Weekly | Competitor tracking | Competitor report |
| Weekly | Tech paper review | Research digest |
| Monthly | Market analysis | Market update |
| Quarterly | Strategic review | Strategy update |

---

## 6. KEY INSIGHTS

### 6.1 Opportunities

1. **No Indonesian AI creative agency tool exists** — first-mover advantage
2. **Self-hosted demand growing** — privacy + cost concerns
3. **Islamic market underserved** — 2B Muslims, few AI tools
4. **Nusantara cultural gap** — no tool understands batik/wayang context
5. **Agency consolidation** — agencies want one tool, not 10

### 6.2 Threats

1. **Big tech entering** — Google/Adobe/Meta could launch competing tools
2. **Open source commoditization** — free tools eroding paid value
3. **Regulatory uncertainty** — AI laws could restrict features
4. **Hardware barriers** — self-hosting needs GPU, limiting adoption
5. **Skill gap** — self-hosting requires technical knowledge

### 6.3 Strategic Recommendations

| Priority | Recommendation | Timeline |
|----------|----------------|----------|
| 🔥 High | Launch managed cloud version (SIDIX Cloud) | Q3 2026 |
| 🔥 High | Build Indonesian/Malay community | Ongoing |
| High | Partner with pesantren/universities for IHOS validation | Q2 2026 |
| High | Create case studies with early agency users | Q2 2026 |
| Medium | Apply for government innovation grants | Q3 2026 |
| Medium | Publish IHOS academic paper | Q4 2026 |
| Low | Explore Middle East market expansion | 2027 |

---

*Research is continuous. SIDIX must keep learning to stay ahead.*
