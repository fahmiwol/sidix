# 10 — SCRIPTS & AUTOMATION
## Deploy · Health Check · Backup · CI/CD · One-Command Operations

**Version:** 1.0
**Date:** 2026-04-25
**Classification:** OPERATIONS MANUAL

---

## 1. DEPLOYMENT SCRIPTS

### 1.1 Full Deploy Script (`deploy.sh`)

```bash
#!/bin/bash
# =============================================================================
# SIDIX VPS Deploy Script
# Pull latest code → backup → install deps → restart → health check
# =============================================================================

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

REPO_DIR="${SIDIX_HOME:-$HOME/sidix}"
BRANCH="main"
BACKUP_DIR="$HOME/.sidix-backups"
LOG_FILE="$REPO_DIR/logs/deploy-$(date +%Y%m%d_%H%M%S).log"

log() { echo -e "${GREEN}[SIDIX-DEPLOY]${NC} $1" | tee -a "$LOG_FILE"; }
warn() { echo -e "${YELLOW}[SIDIX-WARN]${NC} $1" | tee -a "$LOG_FILE"; }
error() { echo -e "${RED}[SIDIX-ERROR]${NC} $1" | tee -a "$LOG_FILE"; }
info() { echo -e "${BLUE}[SIDIX-INFO]${NC} $1" | tee -a "$LOG_FILE"; }

echo "=========================================="
echo "  SIDIX VPS Deploy"
echo "  $(date)"
echo "=========================================="

# Check repo
if [ ! -d "$REPO_DIR/.git" ]; then
    error "Repo not found at $REPO_DIR"
    exit 1
fi

cd "$REPO_DIR"

# Check for updates
info "Checking repository..."
git fetch origin "$BRANCH"
LOCAL=$(git rev-parse HEAD)
REMOTE=$(git rev-parse origin/$BRANCH)

if [ "$LOCAL" = "$REMOTE" ]; then
    warn "Already up-to-date."
    read -p "Restart only? (y/N): " -n 1 -r
    echo
    [[ ! $REPLY =~ ^[Yy]$ ]] && { info "Cancelled."; exit 0; }
    SKIP_PULL=1
else
    info "Update available: ${LOCAL:0:7} → ${REMOTE:0:7}"
    SKIP_PULL=0
fi

# Disk check
DISK_USAGE=$(df -h / | awk 'NR==2 {print $5}' | tr -d '%')
if [ "$DISK_USAGE" -gt 90 ]; then
    error "Disk full: ${DISK_USAGE}%"; exit 1
fi

# Backup
if [ "$SKIP_PULL" = "0" ]; then
    log "Creating backup..."
    mkdir -p "$BACKUP_DIR"
    BACKUP="$BACKUP_DIR/backup-$(date +%Y%m%d_%H%M%S).tar.gz"
    tar -czf "$BACKUP" --exclude='node_modules' --exclude='__pycache__' --exclude='.git' -C "$REPO_DIR" . 2>/dev/null || true
    log "Backup: $BACKUP"
fi

# Pull
if [ "$SKIP_PULL" = "0" ]; then
    log "Pulling from origin/$BRANCH..."
    git pull origin "$BRANCH" | tee -a "$LOG_FILE"
fi

# Dependencies
log "Installing dependencies..."
[ -f "requirements.txt" ] && pip install -r requirements.txt --quiet | tee -a "$LOG_FILE"
[ -f "package.json" ] && npm install --silent | tee -a "$LOG_FILE"

# Database migrations
if [ -f "alembic.ini" ]; then
    info "Running migrations..."
    alembic upgrade head | tee -a "$LOG_FILE" || warn "Migration completed with warnings"
fi

# Restart services
log "Restarting services..."
if command -v pm2 &> /dev/null && [ -f "ecosystem.config.js" ]; then
    pm2 restart ecosystem.config.js --env production | tee -a "$LOG_FILE"
    pm2 save
elif [ -f "/etc/systemd/system/sidix.service" ]; then
    sudo systemctl restart sidix
else
    warn "PM2 or systemd not found. Manual restart required."
fi

# Health check
log "Health check..."
sleep 3
HEALTH_URL="http://localhost:8765/health"
MAX_RETRIES=5
RETRY=0

while [ $RETRY -lt $MAX_RETRIES ]; do
    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "$HEALTH_URL" 2>/dev/null || echo "000")
    if [ "$HTTP_CODE" = "200" ]; then
        log "✅ Health check PASSED"
        break
    fi
    RETRY=$((RETRY + 1))
    warn "Attempt $RETRY/$MAX_RETRIES... (HTTP: $HTTP_CODE)"
    sleep 2
done

if [ $RETRY -eq $MAX_RETRIES ]; then
    error "❌ Health check FAILED"
    error "Check: pm2 logs sidix-backend"
    exit 1
fi

# Summary
NEW_COMMIT=$(git rev-parse --short HEAD)
echo ""
echo "=========================================="
echo "  ✅ DEPLOY COMPLETE"
echo "  Commit: $NEW_COMMIT"
echo "  Time: $(date)"
echo "  Log: $LOG_FILE"
echo "=========================================="
echo ""
echo "Commands:"
echo "  pm2 logs sidix-backend     # View logs"
echo "  pm2 status                 # View status"
echo "  pm2 monit                  # Monitor"
echo ""
```

### 1.2 Quick Restart Script (`restart.sh`)

```bash
#!/bin/bash
set -e

echo "🔄 Restarting SIDIX..."

if ! command -v pm2 &> /dev/null; then
    echo "❌ PM2 not found. Install: npm install -g pm2"
    exit 1
fi

pm2 restart sidix-backend
pm2 restart sidix-dashboard
pm2 restart sidix-health
pm2 show sidix-mcp &>/dev/null && pm2 restart sidix-mcp

sleep 2
echo ""
echo "📊 Status:"
pm2 status
echo ""
echo "✅ Restart complete!"
```

### 1.3 PM2 Ecosystem Config (`ecosystem.config.js`)

```javascript
module.exports = {
  apps: [
    {
      name: 'sidix-backend',
      script: './brain/main.py',
      interpreter: 'python3',
      cwd: '/root/sidix',
      env: { NODE_ENV: 'development', LOG_LEVEL: 'info' },
      env_production: { NODE_ENV: 'production', PORT: 8765, HOST: '0.0.0.0' },
      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      max_restarts: 5,
      min_uptime: '10s',
      restart_delay: 3000,
      max_memory_restart: '2G',
      log_file: './logs/combined.log',
      out_file: './logs/out.log',
      error_file: './logs/error.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      listen_timeout: 10000,
      kill_timeout: 5000,
      wait_ready: true,
      watch: false,
      ignore_watch: ['node_modules', 'logs', '.git', '__pycache__', '*.pyc'],
      env_SIDIX: {
        SIDIX_MCP_ENABLED: 'false',
        SIDIX_MCP_HOST: 'localhost',
        SIDIX_MCP_PORT: '8766',
        OLLAMA_HOST: 'http://localhost:11434',
        OLLAMA_MODEL: 'qwen2.5:7b',
        DATABASE_URL: 'postgresql://sidix:sidix@localhost:5432/sidix',
        MIZAN_ENABLED: 'true',
        JIWA_NAFS_ENABLED: 'true',
        JIWA_AQL_ENABLED: 'true',
        JIWA_QALB_ENABLED: 'true',
        JIWA_RUH_ENABLED: 'true',
        JIWA_HAYAT_ENABLED: 'true',
        JIWA_ILM_ENABLED: 'true',
        JIWA_HIKMAH_ENABLED: 'true',
        TYPO_RESILIENCE_ENABLED: 'true',
        TYPO_MULTILINGUAL_ENABLED: 'true',
        SELF_HEALING_ENABLED: 'true',
        HEALTH_CHECK_INTERVAL: '60',
        QLORA_TRAINING_ENABLED: 'false',
        DASHBOARD_ENABLED: 'true',
        DASHBOARD_PORT: '3000'
      }
    },
    {
      name: 'sidix-mcp',
      script: './brain/sociometer/mcp_server.py',
      interpreter: 'python3',
      cwd: '/root/sidix',
      env: { NODE_ENV: 'development', MCP_MODE: 'stdio' },
      env_production: { NODE_ENV: 'production', MCP_MODE: 'streamable-http', MCP_PORT: 8766, MCP_HOST: '0.0.0.0' },
      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      max_restarts: 3,
      restart_delay: 5000,
      max_memory_restart: '1G',
      log_file: './logs/mcp-combined.log',
      listen_timeout: 10000,
      kill_timeout: 5000,
      autostart: false  // Manual start only for security
    },
    {
      name: 'sidix-dashboard',
      script: './dashboard/server.js',
      cwd: '/root/sidix',
      env: { NODE_ENV: 'development', PORT: 3000 },
      env_production: { NODE_ENV: 'production', PORT: 3000, API_URL: 'http://localhost:8765' },
      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      log_file: './logs/dashboard-combined.log',
      max_memory_restart: '512M',
      autostart: true
    },
    {
      name: 'sidix-health',
      script: './scripts/health-check.sh',
      interpreter: 'bash',
      cwd: '/root/sidix',
      cron_restart: '*/5 * * * *',
      instances: 1,
      exec_mode: 'fork',
      autorestart: false,
      log_file: './logs/health-combined.log',
      autostart: true
    }
  ],
  deploy: {
    production: {
      user: 'root',
      host: ['your-vps-ip'],
      ref: 'origin/main',
      repo: 'https://github.com/fahmiwol/sidix.git',
      path: '/root/sidix',
      'post-deploy': 'bash deploy-scripts/deploy.sh'
    }
  }
};
```

---

## 2. HEALTH MONITORING SCRIPTS

### 2.1 Health Check Script (`health-check.sh`)

```bash
#!/bin/bash
HEALTH_URL="http://localhost:8765/health"
ALERT_WEBHOOK=""  # Fill with Discord/Slack webhook if desired
LOG_FILE="/root/sidix/logs/health-$(date +%Y%m%d).log"

mkdir -p /root/sidix/logs

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Starting health check..." >> "$LOG_FILE"

# HTTP Health
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "$HEALTH_URL" 2>/dev/null || echo "000")
if [ "$HTTP_CODE" != "200" ]; then
    echo "[$(date)] WARNING: HTTP $HTTP_CODE" >> "$LOG_FILE"
    if [ ! -f "/tmp/sidix-restart-lock" ]; then
        echo "[$(date)] Auto-restarting..." >> "$LOG_FILE"
        touch /tmp/sidix-restart-lock
        pm2 restart sidix-backend >> "$LOG_FILE" 2>&1
        sleep 10
        NEW_CODE=$(curl -s -o /dev/null -w "%{http_code}" "$HEALTH_URL" 2>/dev/null || echo "000")
        if [ "$NEW_CODE" = "200" ]; then
            echo "[$(date)] Auto-restore SUCCESS" >> "$LOG_FILE"
            rm -f /tmp/sidix-restart-lock
        else
            echo "[$(date)] CRITICAL: Auto-restore FAILED" >> "$LOG_FILE"
            [ -n "$ALERT_WEBHOOK" ] && curl -s -X POST "$ALERT_WEBHOOK" -H "Content-Type: application/json" -d "{\"text\":\"🚨 SIDIX CRITICAL\"}" >> "$LOG_FILE" 2>&1
        fi
    fi
else
    echo "[$(date)] OK: HTTP 200" >> "$LOG_FILE"
    rm -f /tmp/sidix-restart-lock
fi

# Disk
DISK_USAGE=$(df -h / | awk 'NR==2 {print $5}' | tr -d '%')
[ "$DISK_USAGE" -gt 85 ] && echo "[$(date)] WARNING: Disk ${DISK_USAGE}%" >> "$LOG_FILE"

# Memory
MEM_USAGE=$(free | grep Mem | awk '{printf("%.0f", $3/$2 * 100.0)}')
[ "$MEM_USAGE" -gt 90 ] && echo "[$(date)] WARNING: Memory ${MEM_USAGE}%" >> "$LOG_FILE"

# Ollama
OLLAMA_STATUS=$(curl -s http://localhost:11434/api/tags >/dev/null && echo "UP" || echo "DOWN")
[ "$OLLAMA_STATUS" = "DOWN" ] && echo "[$(date)] WARNING: Ollama DOWN" >> "$LOG_FILE"

# PostgreSQL
DB_STATUS=$(pg_isready -h localhost -p 5432 2>/dev/null && echo "UP" || echo "DOWN")
[ "$DB_STATUS" = "DOWN" ] && echo "[$(date)] WARNING: PostgreSQL DOWN" >> "$LOG_FILE"

echo "[$(date)] Health check completed." >> "$LOG_FILE"
```

---

## 3. BACKUP SCRIPTS

### 3.1 Full Backup Script (`backup.sh`)

```bash
#!/bin/bash
set -e

BACKUP_DIR="$HOME/.sidix-backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
mkdir -p "$BACKUP_DIR"

# Database backup
info() { echo "[BACKUP] $1"; }

info "Backing up PostgreSQL..."
pg_dump -h localhost -U sidix sidix > "$BACKUP_DIR/db_$TIMESTAMP.sql"

info "Backing up Redis..."
redis-cli BGSAVE
sleep 2
cp /var/lib/redis/dump.rdb "$BACKUP_DIR/redis_$TIMESTAMP.rdb" 2>/dev/null || true

info "Backing up code..."
tar -czf "$BACKUP_DIR/code_$TIMESTAMP.tar.gz" \
    --exclude='node_modules' --exclude='__pycache__' --exclude='.git' \
    -C "$HOME/sidix" .

info "Backing up assets..."
mc mirror minio/sidix-assets "$BACKUP_DIR/assets_$TIMESTAMP" 2>/dev/null || \
    aws s3 sync s3://sidix-assets "$BACKUP_DIR/assets_$TIMESTAMP" 2>/dev/null || \
    echo "MinIO/S3 not configured, skipping asset backup"

info "Cleanup old backups (> 30 days)..."
find "$BACKUP_DIR" -name "*.sql" -mtime +30 -delete
find "$BACKUP_DIR" -name "*.tar.gz" -mtime +30 -delete
find "$BACKUP_DIR" -type d -name "assets_*" -mtime +30 -exec rm -rf {} + 2>/dev/null || true

info "Backup complete: $BACKUP_DIR"
ls -lh "$BACKUP_DIR"/*$TIMESTAMP*
```

---

## 4. CI/CD PIPELINE (`.github/workflows/ci.yml`)

```yaml
name: SIDIX CI/CD

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    
    services:
      postgres:
        image: postgres:16
        env:
          POSTGRES_USER: sidix
          POSTGRES_PASSWORD: sidix
          POSTGRES_DB: sidix_test
        ports:
          - 5432:5432
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
      
      redis:
        image: redis:7
        ports:
          - 6379:6379
    
    steps:
      - uses: actions/checkout@v4
      
      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.12'
      
      - name: Install uv
        run: pip install uv
      
      - name: Install dependencies
        run: uv sync
      
      - name: Run lint
        run: uv run ruff check .
      
      - name: Run format check
        run: uv run ruff format --check .
      
      - name: Run tests
        env:
          DATABASE_URL: postgresql://sidix:sidix@localhost:5432/sidix_test
          REDIS_URL: redis://localhost:6379/1
        run: uv run pytest --cov=brain --cov-report=xml --cov-report=term
      
      - name: Upload coverage
        uses: codecov/codecov-action@v4
        with:
          files: ./coverage.xml
          fail_ci_if_error: false

  deploy:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    
    steps:
      - name: Deploy to VPS
        uses: appleboy/ssh-action@v1.0.0
        with:
          host: ${{ secrets.VPS_HOST }}
          username: ${{ secrets.VPS_USER }}
          key: ${{ secrets.VPS_SSH_KEY }}
          script: |
            cd ~/sidix
            bash deploy-scripts/deploy.sh
```

---

## 5. SETUP SCRIPT (`setup.sh`)

```bash
#!/bin/bash
# =============================================================================
# SIDIX First-Time Setup
# Run this on a fresh VPS or development machine
# =============================================================================

set -e

echo "=========================================="
echo "  SIDIX First-Time Setup"
echo "=========================================="

# 1. Update system
sudo apt update && sudo apt upgrade -y

# 2. Install essentials
sudo apt install -y curl wget git python3 python3-pip python3-venv \
    nodejs npm docker.io docker-compose postgresql-client redis-tools

# 3. Install uv (fast Python package manager)
curl -LsSf https://astral.sh/uv/install.sh | sh
source $HOME/.local/bin/env

# 4. Install PM2
sudo npm install -g pm2

# 5. Install Ollama
curl -fsSL https://ollama.com/install.sh | sh

# 6. Start Docker services
sudo docker-compose up -d postgres neo4j redis minio

# 7. Clone repo
read -p "GitHub repo URL [https://github.com/fahmiwol/sidix.git]: " REPO_URL
REPO_URL=${REPO_URL:-"https://github.com/fahmiwol/sidix.git"}
git clone "$REPO_URL" ~/sidix

# 8. Setup environment
cd ~/sidix
cp .env.sample .env
echo "Please edit .env with your settings, then press Enter"
read

# 9. Install Python deps
uv sync

# 10. Run migrations
alembic upgrade head

# 11. Pull Ollama models
ollama pull qwen2.5:7b
ollama pull qwen2.5-coder:14b

# 12. Setup PM2
pm2 start ecosystem.config.js --env production
pm2 save
pm2 startup

# 13. Setup Caddy (if not using nginx)
if ! command -v caddy &> /dev/null; then
    sudo apt install -y debian-keyring debian-archive-keyring apt-transport-https
    curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | sudo gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
    curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | sudo tee /etc/apt/sources.list.d/caddy-stable.list
    sudo apt update
    sudo apt install caddy
fi

# 14. Setup Caddyfile
sudo cp Caddyfile /etc/caddy/Caddyfile
sudo systemctl reload caddy

echo ""
echo "=========================================="
echo "  ✅ SETUP COMPLETE"
echo "=========================================="
echo ""
echo "Next steps:"
echo "  1. Edit ~/sidix/.env with your settings"
echo "  2. Run: pm2 status"
echo "  3. Visit: https://your-domain.com"
echo ""
```

---

## 6. UTILITY COMMANDS (Makefile)

```makefile
.PHONY: help install dev test lint format migrate seed backup deploy

help:
	@echo "SIDIX Commands:"
	@echo "  make install    Install dependencies"
	@echo "  make dev        Start development server"
	@echo "  make test       Run tests"
	@echo "  make lint       Run linter"
	@echo "  make format     Format code"
	@echo "  make migrate    Run database migrations"
	@echo "  make seed       Seed initial data"
	@echo "  make backup     Create backup"
	@echo "  make deploy     Deploy to production"

install:
	uv sync
	cd frontend && npm install

dev:
	pm2 start ecosystem.config.js --env development

test:
	uv run pytest --cov=brain --cov-report=term

lint:
	uv run ruff check .
	cd frontend && npx eslint .

format:
	uv run ruff format .
	cd frontend && npx prettier --write .

migrate:
	alembic upgrade head

seed:
	uv run python scripts/seed.py

backup:
	bash scripts/backup.sh

deploy:
	bash scripts/deploy.sh

# Ollama model management
ollama-pull:
	ollama pull qwen2.5:7b
	ollama pull qwen2.5-coder:14b
	ollama pull qwen3:14b

ollama-list:
	ollama list

# Database management
db-reset:
	alembic downgrade base
	alembic upgrade head

db-seed:
	uv run python scripts/seed.py

# Frontend
frontend-dev:
	cd frontend && npm run dev

frontend-build:
	cd frontend && npm run build

# Docker
docker-up:
	docker-compose up -d

docker-down:
	docker-compose down

docker-logs:
	docker-compose logs -f
```

---

## 7. WINDOWS SCRIPTS (`.bat` files in `scripts/windows/`)

### 7.1 Install Dependencies (`install-deps.bat`)

```batch
@echo off
echo [SIDIX] Installing dependencies...

REM Python
call uv sync

REM Frontend
cd frontend
call npm install
cd ..

REM Ollama models
ollama pull qwen2.5:7b

echo [SIDIX] Done!
pause
```

### 7.2 Start SIDIX (`start-sidix.bat`)

```batch
@echo off
echo [SIDIX] Starting SIDIX...

REM Start backend
start "SIDIX Backend" uv run python brain/main.py

REM Start frontend
cd frontend
start "SIDIX Frontend" npm run dev

echo [SIDIX] Both servers starting...
echo Backend: http://localhost:8765
echo Frontend: http://localhost:3000
pause
```

---

## 8. EMERGENCY PROCEDURES

### 8.1 Complete System Failure

```bash
# 1. Check what's running
pm2 status
sudo systemctl status postgresql
sudo systemctl status redis
docker ps

# 2. If backend is down
pm2 logs sidix-backend --lines 50
pm2 restart sidix-backend

# 3. If database is down
sudo systemctl restart postgresql
pg_isready -h localhost -p 5432

# 4. If Ollama is down
sudo systemctl restart ollama
curl http://localhost:11434/api/tags

# 5. If all else fails — nuclear option
pm2 delete all
pm2 start ecosystem.config.js --env production
pm2 save
```

### 8.2 Rollback After Bad Deploy

```bash
# 1. Stop services
pm2 stop all

# 2. List backups
ls -lt ~/.sidix-backups/

# 3. Restore from backup
BACKUP="~/.sidix-backups/backup-20260425_120000.tar.gz"
cd ~/sidix
tar -xzf "$BACKUP" --strip-components=0

# 4. Restart
pm2 start ecosystem.config.js --env production
```

### 8.3 Database Recovery

```bash
# Restore from SQL dump
createdb sidix_restore
psql -h localhost -U sidix sidix_restore < ~/.sidix-backups/db_20260425_120000.sql

# Switch to restored DB (update .env, restart)
```

---

*Operations should be boring — everything automated, everything documented, everything recoverable.*
