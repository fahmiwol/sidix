# SIDIX COMPLETE SUITE — MASTER GUIDE
## Everything You Need to Build SIDIX · One Folder · Zero Confusion

**Version:** 3.0 — The Complete Rebuild
**Date:** 2026-04-25
**For:** Cursor / Antygravity / Any AI Code Editor
**Language:** Indonesian (brief) + English (code)
**Status:** IMPLEMENTATION-READY

---

## ⚡ QUICK START (Untuk Fahmi yang "Nggak Tau")

```
Langkah 1: Copy semua file di folder ini ke project Cursor
Langkah 2: Berikan prompt di bawah ke Cursor
Langkah 3: Cursor akan generate seluruh codebase
Langkah 4: Deploy ke VPS dengan scripts di 10_SCRIPTS.md
```

**Prompt untuk Cursor:**
```
Tugas: Implementasikan seluruh sistem SIDIX berdasarkan dokumen di folder ini.
Urutan pengerjaan:
1. Baca README.md ini untuk paham struktur
2. Mulai dari 03_ARCHITECTURE.md untuk struktur folder
3. Implementasikan 05_MODULES.md satu per satu
4. Setup database sesuai 02_ERD.md
5. Deploy dengan 10_SCRIPTS.md

Aturan:
- Standing alone — pure Python, no external AI API
- Self-hosted — Ollama untuk inference
- Islamic context — IHOS principles di setiap output
- Modular — tiap modul bisa di-test independent
```

---

## 📁 ISI FOLDER (13 Dokumen Lengkap)

| # | File | Isi | Panjang |
|---|------|-----|---------|
| 1 | `README.md` | **Ini** — Master guide + quick start | ~200 baris |
| 2 | `01_PRD.md` | Product Requirements Document lengkap — Agency OS + Generative + Creative | ~800 baris |
| 3 | `02_ERD.md` | Entity Relationship Diagram — semua tabel database | ~400 baris |
| 4 | `03_ARCHITECTURE.md` | Arsitektur sistem — folder structure + tech stack + data flow | ~500 baris |
| 5 | `04_FRAMEWORK.md` | IHOS Framework + Multilingual Typo + Maqashid Filter | ~600 baris |
| 6 | `05_MODULES.md` | Spec semua modul: brain/, apps/, tools/ | ~700 baris |
| 7 | `06_LEARNING_PATH.md` | Path belajar dari nol sampai jago kontribusi | ~300 baris |
| 8 | `07_RESEARCH.md` | Riset kompetitor + tren teknologi + market analysis | ~400 baris |
| 9 | `08_ANALYSIS.md` | SWOT + Gap Analysis + Risk Matrix + KPI | ~400 baris |
| 10 | `09_METHODS.md` | Methods & Procedures — CQF, Maqashid, Sanad, Naskh, dll | ~500 baris |
| 11 | `10_SCRIPTS.md` | Deploy scripts + automation + health check + CI/CD | ~400 baris |
| 12 | `11_LOGIC.md` | Business Logic + Reaction Flow + State Machine | ~500 baris |
| 13 | `12_INPUT_OUTPUT.md` | I/O spec untuk semua modul — API contract | ~400 baris |
| 14 | `13_ALGORITHMS.md` | Core Algorithms — Jiwa, Raudah, Jariyah, CQF | ~600 baris |

**Total: ~5,700 baris dokumentasi teknis.**

---

## 🗺️ PETA SISTEM SIDIX (Big Picture)

```
USER INPUT (chat / file / voice / image)
    │
    ▼
┌─────────────────────────────────────────────────────────────┐
│ LAYER 1: INTAKE                                              │
│ ├── Multilingual Typo Normalizer (6 bahasa)                  │
│ ├── Script Detector (Latin/Arabic/CJK)                       │
│ └── Intent Classifier (40+ intents)                         │
└──────────────────────┬────────────────────────────────────────┘
                       │
    ┌──────────────────┼──────────────────┐
    │                  │                  │
    ▼                  ▼                  ▼
┌──────────┐   ┌──────────┐   ┌──────────────────┐
│  CHAT    │   │  TOOL    │   │   AGENT MODE     │
│  MODE    │   │  MODE    │   │   (Sidebar)      │
│          │   │          │   │                  │
│ Q&A      │   │ Image    │   │ AYMAN — Creative │
│ General  │   │ Video    │   │ ABOO — Research  │
│ Analysis │   │ Voice    │   │ OOMAR — Producer │
│          │   │ Code     │   │ UTZ — Visual     │
│          │   │ Brand    │   │ ALEY — Copywriter│
│          │   │ Analytics│   │                  │
└────┬─────┘   └────┬─────┘   └────────┬─────────┘
     │              │                    │
     └──────────────┼────────────────────┘
                    │
    ┌───────────────▼────────────────┐
    │    LAYER 2: BRAIN (Jiwa)       │
    │  ┌──────────────────────────┐  │
    │  │ Nafs — Response Engine   │  │
    │  │ (Parametric 60% +       │  │
    │  │  Dynamic 30% +           │  │
    │  │  Static 10%)             │  │
    │  └──────────────────────────┘  │
    │  ┌──────────────────────────┐  │
    │  │ Aql — Learning Engine    │  │
    │  │ (Capture + CQF + Train)  │  │
    │  └──────────────────────────┘  │
    │  ┌──────────────────────────┐  │
    │  │ Qalb — Healing System    │  │
    │  │ (Health → Auto-fix)      │  │
    │  └──────────────────────────┘  │
    │  ┌──────────────────────────┐  │
    │  │ Ruh — Improvement        │  │
    │  │ (Weekly eval + action)   │  │
    │  └──────────────────────────┘  │
    │  ┌──────────────────────────┐  │
    │  │ Hayat — Iterator         │  │
    │  │ (Max 3x retry)           │  │
    │  └──────────────────────────┘  │
    │  ┌──────────────────────────┐  │
    │  │ Ilm — Crawler            │  │
    │  │ (Web + Doc + API)        │  │
    │  └──────────────────────────┘  │
    │  ┌──────────────────────────┐  │
    │  │ Hikmah — Trainer         │  │
    │  │ (QLoRA retrain)          │  │
    │  └──────────────────────────┘  │
    └────────────────────────────────┘
                    │
    ┌───────────────▼────────────────┐
    │   LAYER 3: TOOLS / HANDS       │
    │  ┌──────────────────────────┐  │
    │  │ RAG + Corpus (Mizan)     │  │
    │  │ Knowledge Graph (Neo4j)  │  │
    │  └──────────────────────────┘  │
    │  ┌──────────────────────────┐  │
    │  │ 35 Tools (code, search,  │  │
    │  │ analyze, design, etc.)  │  │
    │  └──────────────────────────┘  │
    │  ┌──────────────────────────┐  │
    │  │ Generative Suite:        │  │
    │  │ · FLUX (image)           │  │
    │  │ · CogVideoX (video)      │  │
    │  │ · Piper/XTTS (voice)     │  │
    │  │ · MusicGen (music)       │  │
    │  │ · Qwen-Coder (code)      │  │
    │  └──────────────────────────┘  │
    │  ┌──────────────────────────┐  │
    │  │ Agency Tools:            │  │
    │  │ · Image Editor           │  │
    │  │ · Video Editor           │  │
    │  │ · Voice Studio           │  │
    │  │ · Brand Guidelines       │  │
    │  │ · Content Calendar       │  │
    │  │ · Analytics Dashboard    │  │
    │  └──────────────────────────┘  │
    └────────────────────────────────┘
                    │
    ┌───────────────▼────────────────┐
    │  LAYER 4: OUTPUT               │
    │  ├── Response text              │
    │  ├── Generated asset (image)     │
    │  ├── Generated asset (video)     │
    │  ├── Generated asset (audio)     │
    │  ├── Generated code (project)    │
    │  ├── Report (analytics)          │
    │  └── Schedule (calendar)         │
    │                                  │
    │  Labels: [FACT] [OPINION]        │
    │          [UNKNOWN] [CREATED]       │
    │          [REFERENCED] [CLAIM]    │
    └──────────────────────────────────┘
```

---

## 🎯 CARA MEMBACA DOKUMEN INI (Khusus untuk yang "Nggak Tau")

### Jika kamu Fahmi (Founder):
1. Baca `01_PRD.md` — paham "SIDIX ini jadi apa ujungnya?"
2. Baca `08_ANALYSIS.md` — paham "apa yang harus diperbaiki dulu?"
3. Baca `10_SCRIPTS.md` — paham "cara deploy ke VPS gimana?"

### Jika kamu Developer (Cursor/Antygravity):
1. Baca `03_ARCHITECTURE.md` — paham struktur folder
2. Baca `02_ERD.md` — paham database schema
3. Baca `05_MODULES.md` — implementasi modul satu per satu
4. Baca `13_ALGORITHMS.md` — implementasi core logic
5. Baca `12_INPUT_OUTPUT.md` — paham API contract antar modul

### Jika kamu Contributor Baru:
1. Baca `06_LEARNING_PATH.md` — path belajar dari nol
2. Baca `04_FRAMEWORK.md` — paham filosofi IHOS
3. Baca `09_METHODS.md` — paham cara kerja internal

---

## 🔧 TEKNOLOGI YANG DIPAKAI

| Layer | Teknologi | Fungsi |
|-------|-----------|--------|
| **LLM Base** | Qwen2.5-7B / Qwen3-14B via Ollama | Text generation, reasoning |
| **Code Model** | Qwen-Coder-14B via Ollama | Code generation |
| **Image** | FLUX.1-dev / FLUX.1-schnell via diffusers | Image generation |
| **Video** | CogVideoX-5B / LTX-Video | Video generation |
| **Voice TTS** | Piper TTS / XTTS v2 | Text-to-speech |
| **Voice STT** | Whisper (OpenAI) via local | Speech-to-text |
| **Music** | MusicGen (AudioCraft) | Music generation |
| **3D** | TripoSR / Shap-E | 3D generation |
| **Backend** | FastAPI (Python) | REST API + WebSocket |
| **Frontend** | React 18 + TypeScript + Tailwind | Dashboard + Editor |
| **Database** | PostgreSQL (main) + Neo4j (KG) | Data + Graph |
| **Cache** | Redis | Session + Queue |
| **Storage** | MinIO / S3 | Asset files |
| **Queue** | Celery + Redis | Background tasks |
| **Deploy** | Docker + Docker Compose | Containerization |
| **Process** | PM2 | Process management |
| **Reverse Proxy** | Caddy | SSL + routing |

---

## 📊 VERSI DAN STATUS

| Komponen | Versi | Status |
|----------|-------|--------|
| Backend Core | v0.8.0 | In Progress |
| Agency OS | v1.0.0 | Design Phase |
| Generative Suite | v0.9.0 | Prototype |
| Typo Resilience | v1.0.0 | Ready |
| Multilingual | v1.0.0 | Ready |
| 7 Pilar Jiwa | v0.3.0 | Partial (kode 20%) |
| Raudah Protocol | v1.0.0 | Ready |
| Jariyah Learning | v2.0.0 | Ready (batch) |

---

## 🚀 ROADMAP SINGKAT (3 Phase)

### Phase 1: Foundation (April — Mei 2026)
- [ ] Repo cleanup + CI/CD
- [ ] Activate Nafs 3-layer (Jiwa)
- [ ] FLUX.1 image pipeline
- [ ] Code validator + multi-file scaffold
- [ ] TTS basic (Piper)
- [ ] Branch system (multi-client)
- [ ] Sidebar UI framework

### Phase 2: Agency Core (Juni — Juli 2026)
- [ ] Video Editor v1
- [ ] Voice Studio v1
- [ ] Content Calendar v1
- [ ] Brand Guidelines Maker v1
- [ ] Analytics Dashboard v1
- [ ] Multi-agent Raudah v2
- [ ] Tiranyx pilot (4 clients)

### Phase 3: Scale (Agustus — Oktober 2026)
- [ ] Advanced Image Editor (layers, AI fill)
- [ ] Advanced Video (AI gen, smart cut)
- [ ] Auto-report generator
- [ ] Game Builder v1
- [ ] 10+ clients on SIDIX
- [ ] White-label for other agencies

---

## 📎 CATATAN PENTING

1. **Semua model self-hosted** — tidak ada API call ke OpenAI/Anthropic/Google. Ollama di localhost.
2. **MCP default OFF** — aktifkan manual saja kalau perlu, untuk keamanan.
3. **Islamic context** — setiap output dicek Maqashid filter. Tidak generate konten yang bertentangan dengan nilai Islam.
4. **Nusantara focus** — typo correction untuk 6 bahasa, voice untuk Javanese/Sundanese, image untuk batik/wayang.
5. **Standing alone** — semua tools bisa jalan tanpa internet (kecuali trend scraping).

---

## 🆘 BUTUH BANTUAN?

Kalau stuck di implementasi:
1. Cek `10_SCRIPTS.md` untuk deploy issues
2. Cek `03_ARCHITECTURE.md` untuk struktur folder
3. Cek `13_ALGORITHMS.md` untuk logic yang bingung
4. Kalau masih stuck, buka `01_PRD.md` dan cari section yang relevan

---

> **"SIDIX bukan cuma AI. SIDIX adalah revolusi cara agency bekerja. Dari manual ke otomatis. Dari generic ke personalized. Dari static ke evolving."**

**Selamat membangun. Standing alone. Bismillah.**
