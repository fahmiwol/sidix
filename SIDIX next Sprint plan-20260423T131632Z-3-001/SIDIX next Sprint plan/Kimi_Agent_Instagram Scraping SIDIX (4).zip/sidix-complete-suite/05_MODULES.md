# 05 — MODULE SPECIFICATIONS
## Every Module in SIDIX: Input, Output, Logic, Dependencies

**Version:** 1.0
**Date:** 2026-04-25
**For:** Developer implementation (Cursor/Antygravity)
**Rule:** Each module is self-contained, testable, and replaceable.

---

## MODULE INDEX

| # | Module | Path | Type | Priority |
|---|--------|------|------|----------|
| 1 | Main Entry | `brain/main.py` | Entry | 🔥 Critical |
| 2 | Config | `brain/config.py` | Config | 🔥 Critical |
| 3 | Nafs Orchestrator | `brain/nafs/` | Pillar | 🔥 Critical |
| 4 | Aql Learning | `brain/aql/` | Pillar | 🔥 Critical |
| 5 | Qalb Healing | `brain/qalb/` | Pillar | Medium |
| 6 | Ruh Improvement | `brain/ruh/` | Pillar | Medium |
| 7 | Hayat Iterator | `brain/hayat/` | Pillar | High |
| 8 | Ilm Crawler | `brain/ilm/` | Pillar | Low |
| 9 | Hikmah Trainer | `brain/hikmah/` | Pillar | High |
| 10 | Jiwa Orchestrator | `brain/jiwa/` | Master | 🔥 Critical |
| 11 | Raudah Protocol | `brain/raudah/` | Multi-Agent | 🔥 Critical |
| 12 | Multilingual | `brain/multilingual/` | Framework | 🔥 Critical |
| 13 | Persona System | `brain/persona/` | Framework | 🔥 Critical |
| 14 | Tool Registry | `brain/tools/` | Tools | 🔥 Critical |
| 15 | Corpus | `brain/corpus/` | Knowledge | 🔥 Critical |
| 16 | Serve Layer | `brain/serve/` | API | 🔥 Critical |
| 17 | Agency OS | `apps/agency_os/` | Application | High |
| 18 | Image Editor | `apps/creative_suite/image_editor/` | Editor | High |
| 19 | Video Editor | `apps/creative_suite/video_editor/` | Editor | High |
| 20 | Voice Studio | `apps/creative_suite/voice_studio/` | Editor | Medium |
| 21 | Brand Guidelines | `apps/creative_suite/brand_guidelines/` | Editor | Medium |
| 22 | Database | `database/` | Infrastructure | 🔥 Critical |
| 23 | Frontend | `frontend/src/` | UI | 🔥 Critical |

---

## 1. MAIN ENTRY (`brain/main.py`)

### Purpose
Entry point for SIDIX. Initializes all systems and starts the server.

### Input
```python
# Environment variables from .env
# Command line arguments (optional)
```

### Output
```python
# Running FastAPI server on port 8765
# All services initialized
```

### Logic
```
1. Load config from .env
2. Initialize database connection
3. Initialize Redis connection
4. Load Ollama models (lazy loading)
5. Initialize Knowledge Graph
6. Initialize 7 Pillar systems
7. Initialize tool registry
8. Start FastAPI server
9. Start background workers (Celery)
10. Start health monitor
```

### Dependencies
- `brain/config.py`
- `database/connection.py`
- `brain/jiwa/orchestrator.py`

---

## 2. CONFIG (`brain/config.py`)

### Purpose
Central configuration management. Single source of truth for all settings.

### Input
```python
# .env file
# Environment variables
# Default values
```

### Output
```python
@dataclass
class SIDIXConfig:
    env: str                    # development | staging | production
    debug: bool
    secret_key: str
    
    # Database
    database_url: str
    neo4j_uri: str
    redis_url: str
    
    # Storage
    minio_endpoint: str
    minio_bucket: str
    
    # AI Models
    ollama_host: str
    default_model: str
    code_model: str
    reasoning_model: str
    
    # Agency OS
    agency_mode: bool
    max_clients: int
    
    # Feature Flags
    image_generation: bool
    video_generation: bool
    voice_generation: bool
    code_generation: bool
    trend_scanning: bool
    auto_learning: bool
    
    # MCP
    mcp_enabled: bool
    mcp_host: str
    mcp_port: int
```

### Logic
```
1. Load .env file
2. Override with environment variables
3. Validate required fields
4. Set defaults for missing values
5. Return immutable config object
```

---

## 3. NAFS ORCHESTRATOR (`brain/nafs/`)

### Files
- `response_orchestrator.py` — Main response logic
- `knowledge_router.py` — Route query to correct knowledge layer
- `epistemic_labeler.py` — Add [FACT]/[OPINION]/[UNKNOWN] labels

### Input
```python
{
    "query": str,                    # User question (after typo correction)
    "conversation_id": str,         # Context
    "client_id": str,               # Branch context
    "persona": str,                 # AYMAN/ABOO/OOMAR/ALEY/UTZ
    "maqashid_mode": str            # CREATIVE/ACADEMIC/IJTIHAD/GENERAL
}
```

### Output
```python
{
    "response": str,                 # Final response text
    "knowledge_layers_used": list,   # ["parametric", "dynamic", "static"]
    "epistemic_labels": list,        # ["FACT", "OPINION"]
    "sanad_chain": list,             # [{"source": "", "tier": 1}]
    "confidence": float,            # 0.0 - 1.0
    "persona_used": str
}
```

### Logic
```
1. Classify query topic
2. Select knowledge layers based on topic routing
3. Query parametric knowledge (LLM)
4. Query dynamic knowledge (Knowledge Graph)
5. Query static knowledge (Corpus)
6. Fuse responses with weights (60/30/10)
7. Apply epistemic labeling
8. Apply Maqashid filter
9. Format response
```

### Dependencies
- `brain/corpus/` (static knowledge)
- `database/kg_nodes` (dynamic knowledge)
- Ollama API (parametric knowledge)

---

## 4. AQL LEARNING (`brain/aql/`)

### Files
- `learning_loop.py` — Main learning engine
- `drift_detector.py` — Detect model performance drift
- `feedback_processor.py` — Process 👍/👎 feedback

### Input (learning_loop.py)
```python
{
    "query": str,
    "response": str,
    "user_feedback": str,           # thumbs_up | thumbs_down | none
    "conversation_id": str,
    "client_id": str,
    "cqf_score": float
}
```

### Output
```python
{
    "captured": bool,
    "training_pair_id": str,        # If captured for training
    "kg_updated": bool,             # If Knowledge Graph updated
    "drift_detected": bool,
    "drift_details": dict
}
```

### Logic
```
1. Anonymize (remove PII: emails, phones, names)
2. Score interaction with CQF
3. If CQF >= 7.0 AND no PII → capture to training_pairs
4. Extract knowledge nuggets → update KG
5. Check if enough new data for drift detection
6. If drift detected → queue retrain job
```

### Dependencies
- `database/training_pairs`
- `database/kg_nodes`
- `brain/hikmah/retrain_pipeline.py`

---

## 5. QALB HEALING (`brain/qalb/`)

### Files
- `health_monitor.py` — Check system health
- `auto_healer.py` — Auto-fix actions
- `alert_manager.py` — Send alerts

### Input
```python
{
    "component": str,               # backend | ollama | database | disk | memory
    "check_interval_seconds": int
}
```

### Output
```python
{
    "status": str,                  # healthy | degraded | sick | critical
    "metrics": dict,                # {cpu: 45, memory: 72, disk: 60}
    "actions_taken": list,           # ["reduced_batch_size", "switched_to_cpu"]
    "alert_sent": bool
}
```

### Logic
```
1. Check system metrics every 60 seconds
2. Compare against thresholds
3. If DEGRADED: reduce batch size, switch to CPU
4. If SICK: restart service, clear cache
5. If CRITICAL: full restart, alert admin, safe mode
6. Log all actions to health_checks table
```

### Dependencies
- PostgreSQL (health_checks table)
- Redis (cache clearing)
- PM2 (service restart)

---

## 6. RUH IMPROVEMENT (`brain/ruh/`)

### Files
- `improvement_engine.py` — Weekly self-evaluation
- `action_planner.py` — Create improvement plan

### Input
```python
{
    "period": str,                  # weekly | monthly
    "dimensions": list              # ["model_quality", "efficiency", "knowledge", "satisfaction"]
}
```

### Output
```python
{
    "report": str,                  # Natural language report
    "scores": dict,                 # {"model_quality": 8.2, "efficiency": 7.5, ...}
    "weakest_dimension": str,
    "action_plan": list,             # ["increase training data", "optimize inference"]
    "training_triggered": bool
}
```

### Logic
```
1. Aggregate metrics from past week
2. Score each dimension (0-10)
3. Identify weakest dimension
4. Generate improvement action plan
5. If 2+ dimensions < 6.0 → trigger retraining
6. Store report in database
7. Present to admin dashboard
```

---

## 7. HAYAT ITERATOR (`brain/hayat/`)

### Files
- `iteration_engine.py` — Generate-evaluate-refine loop
- `quality_gate.py` — CQF gate check

### Input
```python
{
    "task": str,                    # Description of what to generate
    "max_iterations": int,           # Default 3
    "cqf_target": float,            # Default 8.0
    "agent": str                     # AYMAN/UTZ/ALEY
}
```

### Output
```python
{
    "result": str,                  # Best output
    "iterations": int,              # How many iterations used
    "cqf_score": float,
    "improvement_log": list         # [{"iteration": 1, "cqf": 6.5, "issue": "..."}]
}
```

### Logic
```
1. Generate initial output
2. Evaluate with CQF
3. If CQF >= 8.0 → return
4. If < 8.0 and iterations < 3:
   a. Analyze weaknesses
   b. Refine prompt/task
   c. Regenerate
   d. Evaluate again
5. Return best output (even if < 8.0 after 3 tries)
```

---

## 8. ILM CRAWLER (`brain/ilm/`)

### Files
- `web_crawler.py` — Ethical web scraping
- `document_processor.py` — PDF/DOCX processing
- `api_collector.py` — API data collection

### Input
```python
{
    "query": str,                   # What knowledge gap to fill
    "sources": list,                # ["web", "document", "api"]
    "max_results": int,             # Default 10
    "ethical_only": bool            # Default True
}
```

### Output
```python
{
    "results": list,                # [{"source": "url", "content": "...", "confidence": 0.9}]
    "kg_entries_added": int,
    "sanad_chains": list
}
```

### Logic
```
1. Check robots.txt (respect webmaster rules)
2. Search for relevant content
3. Extract text with readability algorithm
4. Fact-check against existing KG (avoid contradictions)
5. Store in kg_nodes with source attribution
6. Label with Sanad tier
```

---

## 9. HIKMAH TRAINER (`brain/hikmah/`)

### Files
- `retrain_pipeline.py` — QLoRA retrain
- `ab_tester.py` — A/B test new vs old
- `deploy_manager.py` — Deploy/rollback

### Input
```python
{
    "trigger": str,                 # drift_detected | manual | scheduled
    "dataset_size_min": int,        # Default 5000
    "base_model": str,              # "qwen2.5-7b-instruct"
    "lora_r": int,                  # 64
    "lora_alpha": int,              # 128
    "epochs": int                   # 3
}
```

### Output
```python
{
    "training_run_id": str,
    "status": str,                  # queued | training | completed | failed
    "train_loss": float,
    "eval_loss": float,
    "eval_bleu": float,
    "ab_test_result": str,          # new_better | old_better | tie
    "deployed": bool,
    "model_path": str
}
```

### Logic
```
1. Collect approved training_pairs (status = approved)
2. Filter by quality (CQF >= 7.0)
3. Split: 90% train, 10% eval
4. Start QLoRA training (Kaggle or local GPU)
5. Monitor loss curves
6. Evaluate on eval set (BLEU, ROUGE)
7. A/B test: new adapter vs current
8. If new wins by >5% → deploy
9. Else → keep current, archive new
```

### Dependencies
- `database/training_pairs`
- `database/training_runs`
- Kaggle API or local GPU

---

## 10. JIWA ORCHESTRATOR (`brain/jiwa/`)

### Files
- `orchestrator.py` — Master orchestrator

### Input
```python
{
    "request": dict,                # Full user request
    "type": str,                   # chat | creative | tool | agency
}
```

### Output
```python
{
    "response": str,
    "assets": list,                # Generated assets (if any)
    "actions_taken": list,          # ["nafs_responded", "aql_captured", "hayat_iterated"]
    "health": str,                  # healthy | degraded | sick
    "layers_used": list,
    "iterations": int,
    "time_ms": int
}
```

### Logic
```
1. Receive request
2. Run Multilingual Pipeline (typo correction)
3. Route to correct handler (chat/creative/tool/agency)
4. Activate relevant personas
5. Run Nafs (response generation)
6. Run Hayat (quality iteration)
7. Run Maqashid filter
8. Run CQF scoring
9. Run Aql (capture for learning)
10. Run Qalb (health check)
11. Return response
```

---

## 11. RAUDAH PROTOCOL (`brain/raudah/`)

### Files
- `task_graph.py` — DAG task decomposition
- `agent_pool.py` — Agent management
- `consensus.py` — Consensus mechanism
- `collaborative_learning.py` — Cross-agent learning

### Input
```python
{
    "brief": str,                   # User creative brief
    "agents_needed": list,          # ["AYMAN", "UTZ", "ALEY"]
    "client_id": str,
    "deadline_hours": int
}
```

### Output
```python
{
    "project_id": str,
    "status": str,                  # pending | in_progress | completed
    "deliverables": dict,           # {"images": [], "videos": [], "copy": []}
    "agent_contributions": dict,    # {"AYMAN": "concept", "UTZ": "visuals"}
    "cqf_score": float,
    "timeline": list                # [{"agent": "", "task": "", "status": ""}]
}
```

### Logic
```
1. Decompose brief into tasks
2. Create DAG (dependencies between tasks)
3. Assign tasks to agents based on expertise
4. Execute independent tasks in parallel
5. Collect results
6. Run consensus on conflicting outputs
7. Synthesize final deliverable
8. Run quality gate
9. Deliver to user
10. Log cross-agent learnings
```

---

## 12. MULTILINGUAL (`brain/multilingual/`)

### Files
- `script_detector.py` — Detect script type
- `language_detector.py` — Detect language (6 languages)
- `typo_dictionaries.py` — 1,150+ typo patterns
- `universal_corrector.py` — Correct typos
- `semantic_matcher.py` — Cross-lingual intent
- `cultural_responder.py` — Cultural response
- `pipeline.py` — End-to-end pipeline

### Input
```python
{
    "text": str                     # Raw user input with typos
}
```

### Output
```python
{
    "original": str,
    "corrected": str,
    "language": str,                # id | en | ar-latin | ms | tl | hi-latin
    "corrections": list,
    "confidence": float
}
```

---

## 13. PERSONA SYSTEM (`brain/persona/`)

### Files
- `ayman.py` — Creative Director persona
- `aboo.py` — Research Director persona
- `oomar.py` — Producer persona
- `utz.py` — Visual Artist persona
- `aley.py` — Communicator persona
- `persona_router.py` — Auto-select persona

### Input
```python
{
    "query": str,
    "context": dict,
    "client_id": str
}
```

### Output
```python
{
    "selected_persona": str,        # AYMAN | ABOO | OOMAR | UTZ | ALEY
    "system_prompt": str,           # Persona-specific system prompt
    "mode": str                     # CREATIVE | ACADEMIC | IJTIHAD | GENERAL
}
```

---

## 14. TOOL REGISTRY (`brain/tools/`)

### Files
- `registry.py` — Tool registration and routing
- `code_sandbox.py` — Code execution
- `code_validator.py` — Code validation
- `code_analyze.py` — Code analysis
- `search_web.py` — Web search
- `search_docs.py` — Document search
- `generate_image.py` — Image generation
- `generate_video.py` — Video generation
- `generate_audio.py` — Audio generation
- `analyze_sentiment.py` — Sentiment analysis
- `analyze_market.py` — Market analysis
- `schedule_post.py` — Social scheduling
- ... (20+ more tools)

### Tool Interface
```python
class BaseTool:
    name: str
    description: str
    parameters: dict
    
    async def execute(self, params: dict) -> dict:
        """Execute tool. Return result."""
        pass
    
    async def validate(self, params: dict) -> bool:
        """Validate parameters before execution."""
        pass
```

---

## 15. CORPUS (`brain/corpus/`)

### Structure
```
brain/corpus/
├── ihos/                       # Islamic principles (immutable)
│   ├── tawhid.md
│   ├── adl.md
│   ├── ilm.md
│   ├── hikmah.md
│   └── rahmah.md
│
├── maqashid/                   # Maqashid filter rules
│   ├── creative_rules.md
│   ├── academic_rules.md
│   ├── ijtihad_rules.md
│   └── general_rules.md
│
├── brand_frameworks/           # Branding knowledge
│   ├── positioning.md
│   ├── identity.md
│   └── storytelling.md
│
├── copy_formulas/              # Copywriting frameworks
│   ├── aida.md
│   ├── pas.md
│   └── fab.md
│
└── nusantara/                  # Cultural knowledge
    ├── wayang.md
    ├── batik.md
    ├── adat.md
    └── islamic_art.md
```

---

## 16. SERVE LAYER (`brain/serve/`)

### Files
- `agent_react.py` — ReAct loop (legacy entry)
- `api.py` — FastAPI routes
- `websocket.py` — WebSocket handler
- `middleware.py` — Auth, rate limit, CORS

### API Routes
See `03_ARCHITECTURE.md` Section 5.1 for full API spec.

### WebSocket Events
See `03_ARCHITECTURE.md` Section 5.2 for full WebSocket spec.

---

## 17. AGENCY OS (`apps/agency_os/`)

### Files
- `dashboard.py` — Agency dashboard API
- `clients.py` — Client/branch management
- `campaigns.py` — Campaign management
- `calendar.py` — Content calendar
- `analytics.py` — Analytics API
- `notifications.py` — Notifications

### Input (campaigns.py — generate campaign)
```python
{
    "client_id": str,
    "name": str,
    "objective": str,
    "target_audience": str,
    "budget": float,
    "start_date": str,
    "end_date": str
}
```

### Output
```python
{
    "campaign_id": str,
    "creative_concept": str,
    "visual_direction": str,
    "messaging_framework": str,
    "assets": list,                 # Generated asset IDs
    "content_calendar": list,       # Scheduled posts
    "status": str                   # draft | approved | active
}
```

---

## 18. IMAGE EDITOR (`apps/creative_suite/image_editor/`)

### Files
- `canvas.py` — Canvas rendering engine
- `layers.py` — Layer management
- `tools.py` — Tool implementations (brush, select, text)
- `ai_generate.py` — AI generation in editor
- `export.py` — Multi-format export

### Input (ai_generate.py)
```python
{
    "prompt": str,
    "width": int,
    "height": int,
    "style": str,                   # Optional style preset
    "negative_prompt": str,
    "steps": int,                   # 20-50
    "guidance_scale": float         # 5.0-10.0
}
```

### Output
```python
{
    "asset_id": str,
    "image_url": str,
    "thumbnail_url": str,
    "width": int,
    "height": int,
    "cqf_score": float,
    "generation_time_ms": int
}
```

---

## 19. VIDEO EDITOR (`apps/creative_suite/video_editor/`)

### Files
- `timeline.py` — Timeline engine
- `tracks.py` — Track management
- `transitions.py` — Transition effects
- `captions.py` — Auto-caption generation
- `export.py` — Video export

### Input (export.py)
```python
{
    "project_id": str,
    "format": str,                  # mp4 | mov | webm | gif
    "resolution": str,                # 1080p | 4k
    "fps": int,                     # 24 | 30 | 60
    "quality": str                  # draft | standard | high
}
```

### Output
```python
{
    "asset_id": str,
    "video_url": str,
    "duration": int,
    "file_size_mb": float,
    "thumbnail_url": str,
    "preview_gif_url": str
}
```

---

## 20. VOICE STUDIO (`apps/creative_suite/voice_studio/`)

### Files
- `recorder.py` — Browser recording
- `tts.py` — Text-to-speech
- `voice_clone.py` — Voice cloning
- `effects.py` — Audio effects

### Input (tts.py)
```python
{
    "text": str,
    "voice": str,                   # "dewi" | "bima" | "fatima" | ...
    "language": str,                # id | en | ar | ms | tl | hi
    "speed": float,                 # 0.5 - 2.0
    "pitch": float,                 # -10 to +10
    "emotion": str                  # neutral | happy | sad | serious
}
```

### Output
```python
{
    "asset_id": str,
    "audio_url": str,
    "duration": int,
    "format": str,                  # mp3 | wav
    "sample_rate": int
}
```

---

## 21. BRAND GUIDELINES (`apps/creative_suite/brand_guidelines/`)

### Files
- `extractor.py` — Auto-extract from website
- `generator.py` — Generate guidelines
- `mockup.py` — Mockup generator
- `export.py` — Export PDF/Web/Figma

### Input (extractor.py)
```python
{
    "client_id": str,
    "website_url": str,             # "https://kai.id"
    "social_urls": list             # ["https://instagram.com/keretaapikita"]
}
```

### Output
```python
{
    "brand_id": str,
    "extracted_colors": list,
    "extracted_fonts": list,
    "extracted_logo_url": str,
    "extracted_tone": str,
    "confidence": float
}
```

---

## 22. DATABASE (`database/`)

### Files
- `connection.py` — DB connection manager
- `models.py` — SQLModel definitions (see `02_ERD.md`)
- `migrations/` — Alembic migrations
- `seeders/` — Initial data

### Input
```python
# Environment variables
DATABASE_URL = "postgresql://..."
NEO4J_URI = "bolt://..."
REDIS_URL = "redis://..."
```

### Output
```python
# SQLAlchemy session
# Neo4j driver
# Redis client
```

---

## 23. FRONTEND (`frontend/src/`)

### Structure
```
frontend/src/
├── components/
│   ├── sidebar/
│   │   ├── Sidebar.tsx           # Main sidebar container
│   │   ├── ClientSwitcher.tsx    # Branch switcher
│   │   ├── AgentPanel.tsx        # Agent mode panel
│   │   └── ToolPanel.tsx         # Built-in tools panel
│   │
│   ├── chat/
│   │   ├── ChatWindow.tsx        # Main chat area
│   │   ├── MessageBubble.tsx     # Individual message
│   │   ├── TypingIndicator.tsx   # Agent typing
│   │   └── EpistemicBadge.tsx    # [FACT]/[OPINION] badges
│   │
│   ├── image_editor/
│   │   ├── Canvas.tsx            # Fabric.js canvas
│   │   ├── LayerPanel.tsx        # Layer management
│   │   ├── ToolBar.tsx           # Tools (brush, select, text)
│   │   └── AIControl.tsx         # AI generation controls
│   │
│   ├── video_editor/
│   │   ├── Timeline.tsx          # Video timeline
│   │   ├── Preview.tsx           # Video preview
│   │   ├── TrackControls.tsx     # Track management
│   │   └── ExportDialog.tsx      # Export settings
│   │
│   ├── voice_studio/
│   │   ├── Recorder.tsx          # Audio recorder
│   │   ├── TTSPanel.tsx          # TTS controls
│   │   ├── VoiceSelector.tsx     # Voice selection
│   │   └── Waveform.tsx          # Audio waveform
│   │
│   ├── brand_guidelines/
│   │   ├── BrandOverview.tsx     # Overview tab
│   │   ├── ColorPalette.tsx      # Color system
│   │   ├── Typography.tsx        # Font system
│   │   └── ExportDialog.tsx      # Export options
│   │
│   ├── analytics/
│   │   ├── Dashboard.tsx         # Main dashboard
│   │   ├── KPICards.tsx          # KPI cards
│   │   ├── Charts.tsx            # Charts
│   │   └── ReportGenerator.tsx   # Report generation
│   │
│   └── calendar/
│       ├── CalendarView.tsx      # Calendar grid
│       ├── PostCard.tsx          # Individual post
│       └── DragDropProvider.tsx  # Drag-drop context
│
├── pages/
│   ├── Dashboard.tsx
│   ├── Chat.tsx
│   ├── ClientWorkspace.tsx
│   ├── CampaignBuilder.tsx
│   ├── ImageEditor.tsx
│   ├── VideoEditor.tsx
│   ├── VoiceStudio.tsx
│   ├── BrandGuidelines.tsx
│   ├── Analytics.tsx
│   └── Calendar.tsx
│
├── hooks/
│   ├── useWebSocket.ts           # WebSocket connection
│   ├── useAuth.ts              # Authentication
│   ├── useClient.ts            # Active client context
│   ├── useAgent.ts             # Active agent context
│   └── useAssetGeneration.ts   # Asset generation polling
│
├── stores/
│   ├── authStore.ts            # Zustand auth state
│   ├── clientStore.ts          # Active client/branch
│   ├── agentStore.ts           # Active agent
│   ├── chatStore.ts            # Chat messages
│   └── uiStore.ts              # UI state (sidebar open, etc.)
│
├── services/
│   ├── api.ts                  # Axios/Fetch wrapper
│   ├── authService.ts
│   ├── clientService.ts
│   ├── campaignService.ts
│   ├── assetService.ts
│   └── websocketService.ts
│
├── types/
│   ├── api.ts                  # API response types
│   ├── models.ts               # Business model types
│   └── components.ts           # Component prop types
│
└── utils/
    ├── formatters.ts           # Date, currency formatters
    ├── validators.ts           # Input validation
    └── constants.ts            # App constants
```

---

## MODULE DEPENDENCY GRAPH

```
main.py
├── config.py
├── database/
│   ├── connection.py
│   ├── models.py
│   └── migrations/
├── brain/
│   ├── jiwa/
│   │   └── orchestrator.py
│   │       ├── nafs/response_orchestrator.py
│   │       │   ├── corpus/ (static knowledge)
│   │       │   └── database/kg_nodes (dynamic)
│   │       ├── aql/learning_loop.py
│   │       │   ├── database/training_pairs
│   │       │   └── hikmah/retrain_pipeline.py
│   │       ├── qalb/health_monitor.py
│   │       ├── hayat/iteration_engine.py
│   │       ├── multilingual/pipeline.py
│   │       ├── persona/persona_router.py
│   │       └── tools/registry.py
│   ├── raudah/
│   │   ├── task_graph.py
│   │   ├── agent_pool.py
│   │   └── consensus.py
│   └── serve/
│       ├── api.py
│       └── websocket.py
├── apps/
│   ├── agency_os/
│   │   ├── dashboard.py
│   │   ├── clients.py
│   │   ├── campaigns.py
│   │   └── calendar.py
│   └── creative_suite/
│       ├── image_editor/
│       ├── video_editor/
│       ├── voice_studio/
│       └── brand_guidelines/
└── frontend/
    └── src/
        ├── components/
        ├── pages/
        ├── hooks/
        ├── stores/
        └── services/
```

---

*Each module in this spec is independently testable.*
*Dependencies flow downward: serve → jiwa → pillars → tools → corpus.*
*Agency OS sits at the same level as serve, consuming the brain.*
*Creative Suite sits below Agency OS, providing editor functionality.*
