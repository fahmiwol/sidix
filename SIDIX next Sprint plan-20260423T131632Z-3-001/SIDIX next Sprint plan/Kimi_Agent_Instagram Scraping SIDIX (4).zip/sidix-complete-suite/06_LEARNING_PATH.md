# 06 — LEARNING PATH
## From Zero to SIDIX Mastery

**Version:** 1.0
**Date:** 2026-04-25
**Target Audience:** New contributors, developers joining SIDIX
**Philosophy:** Everyone starts from zero. IHOS teaches that knowledge is a journey (ilm), not a destination.

---

## LEVEL 0: PREREQUISITES (Before Touching SIDIX)

### 0.1 Required Knowledge

| Topic | Level | Resource | Time |
|-------|-------|----------|------|
| Python 3.10+ | Intermediate | Python official docs | 1 week |
| FastAPI | Basic | FastAPI tutorial | 3 days |
| SQL (PostgreSQL) | Basic | PostgreSQL tutorial | 3 days |
| Git & GitHub | Intermediate | Pro Git book | 2 days |
| Docker basics | Basic | Docker Getting Started | 2 days |
| React + TypeScript | Basic | React docs | 1 week |
| Tailwind CSS | Basic | Tailwind docs | 2 days |

### 0.2 Recommended Knowledge

| Topic | Level | Resource | Time |
|-------|-------|----------|------|
| LLM concepts | Basic | Hugging Face course | 3 days |
| RAG systems | Basic | LangChain docs | 2 days |
| Islamic epistemology | Basic | IHOS principles doc | 1 day |
| Nusantara culture | Awareness | Wikipedia + travel | Ongoing |

### 0.3 Environment Setup

```bash
# 1. Clone repo
git clone https://github.com/fahmiwol/sidix.git
cd sidix

# 2. Install Python dependencies
pip install -r requirements.txt
# or with uv
uv sync

# 3. Install frontend dependencies
cd frontend && npm install

# 4. Setup environment
cp .env.sample .env
# Edit .env with your settings

# 5. Start databases
docker-compose up -d postgres neo4j redis minio

# 6. Run migrations
alembic upgrade head

# 7. Start Ollama
ollama serve
ollama pull qwen2.5:7b

# 8. Start backend
python brain/main.py

# 9. Start frontend (in another terminal)
cd frontend && npm run dev
```

---

## LEVEL 1: FOUNDATION (Week 1-2)

### 1.1 Understand IHOS Philosophy
- [ ] Read `04_FRAMEWORK.md` Part A (IHOS)
- [ ] Understand the 5 principles: Tawhid, Adl, Ilm, Hikmah, Rahmah
- [ ] Understand epistemic labels: [FACT], [OPINION], [UNKNOWN]
- [ ] Understand Maqashid filter: CREATIVE, ACADEMIC, IJTIHAD, GENERAL
- [ ] Understand Sanad chain and Naskh handler

**Deliverable:** Can explain IHOS to someone in 5 minutes.

### 1.2 Understand Architecture
- [ ] Read `03_ARCHITECTURE.md`
- [ ] Draw the system architecture diagram from memory
- [ ] Understand 3-layer brain: Parametric → Dynamic → Static
- [ ] Understand folder structure
- [ ] Run the system locally and make a chat request

**Deliverable:** Can explain where each file lives and why.

### 1.3 Understand Database
- [ ] Read `02_ERD.md`
- [ ] Connect to PostgreSQL and explore tables
- [ ] Run 5 SQL queries to understand data relationships
- [ ] Understand Neo4j Knowledge Graph concept

**Deliverable:** Can write a query to find all campaigns for a client.

---

## LEVEL 2: CORE SYSTEMS (Week 3-4)

### 2.1 Multilingual & Typo System
- [ ] Read `04_FRAMEWORK.md` Part B (Multilingual)
- [ ] Test typo correction with 10 Indonesian typos
- [ ] Test typo correction with 10 English typos
- [ ] Add 5 new typo entries to dictionary
- [ ] Understand 5-layer architecture

**Deliverable:** Can explain how "gmn" becomes "gimana" through all 5 layers.

### 2.2 Persona System
- [ ] Read `04_FRAMEWORK.md` Part C (Personas)
- [ ] Test each persona with same query, observe differences
- [ ] Understand persona selection logic
- [ ] Add a new trigger keyword to one persona

**Deliverable:** Can predict which persona will be selected for 5 sample queries.

### 2.3 Tool System
- [ ] Read `05_MODULES.md` Section 14 (Tool Registry)
- [ ] Add a new simple tool (e.g., "calculate_age")
- [ ] Test tool execution via API
- [ ] Understand tool interface pattern

**Deliverable:** Created and registered a working tool.

### 2.4 Nafs (Response Engine)
- [ ] Read `04_FRAMEWORK.md` Part D.1 (Nafs)
- [ ] Understand 3-layer knowledge fusion
- [ ] Test topic routing with 10 different topics
- [ ] Observe how weights change per topic

**Deliverable:** Can explain why "agama" topic uses STATIC layer.

---

## LEVEL 3: ADVANCED SYSTEMS (Week 5-6)

### 3.1 Raudah Protocol (Multi-Agent)
- [ ] Read `04_FRAMEWORK.md` Part E (Raudah)
- [ ] Understand TaskGraph DAG concept
- [ ] Test multi-agent workflow with a simple task
- [ ] Understand consensus mechanism

**Deliverable:** Can decompose a creative brief into a TaskGraph.

### 3.2 CQF (Quality Framework)
- [ ] Read `04_FRAMEWORK.md` Part F (CQF)
- [ ] Score 5 outputs manually using 10 criteria
- [ ] Understand scoring thresholds
- [ ] Implement a new CQF criterion

**Deliverable:** Can score any AI output objectively.

### 3.3 Aql (Learning Engine)
- [ ] Read `04_FRAMEWORK.md` Part D.2 (Aql)
- [ ] Understand drift detection concept
- [ ] Review training_pairs table
- [ ] Understand feedback processing

**Deliverable:** Can explain how SIDIX learns from interactions.

### 3.4 Hikmah (Training Pipeline)
- [ ] Read `04_FRAMEWORK.md` Part D.7 (Hikmah)
- [ ] Understand QLoRA concept
- [ ] Review training_runs table
- [ ] Understand A/B testing flow

**Deliverable:** Can explain the full retrain pipeline from trigger to deploy.

---

## LEVEL 4: AGENCY OS (Week 7-8)

### 4.1 Branch System
- [ ] Read `01_PRD.md` Section 8 (Branching)
- [ ] Create a test client branch
- [ ] Switch between branches
- [ ] Understand shared intelligence concept

**Deliverable:** Created 2 branches and observed isolated data.

### 4.2 Creative Suite
- [ ] Test Image Editor: generate, edit, export
- [ ] Test Video Editor: timeline, caption, export
- [ ] Test Voice Studio: TTS, record, export
- [ ] Test Brand Guidelines: extract, generate, export

**Deliverable:** Generated a complete asset package for a mock campaign.

### 4.3 Analytics & Calendar
- [ ] Understand analytics data model
- [ ] Create a content calendar entry
- [ ] Understand approval workflow
- [ ] Generate a sample report

**Deliverable:** Created and scheduled a week's worth of content.

---

## LEVEL 5: MASTERY (Week 9-12)

### 5.1 Custom Persona Development
- [ ] Create a new persona (e.g., "FINA — Finance Analyst")
- [ ] Define system prompt
- [ ] Define trigger keywords
- [ ] Test with 20 queries

**Deliverable:** New persona works correctly and is documented.

### 5.2 Custom Tool Development
- [ ] Create a complex tool (e.g., "competitor_scraper")
- [ ] Handle edge cases
- [ ] Add validation
- [ ] Write tests

**Deliverable:** Tool is merged to main branch.

### 5.3 Custom Model Fine-tuning
- [ ] Prepare dataset for fine-tuning
- [ ] Run QLoRA training (on Kaggle or local)
- [ ] Evaluate results
- [ ] A/B test against current model

**Deliverable": Successfully trained and deployed a LoRA adapter.

### 5.4 Plugin Development (MCP)
- [ ] Understand MCP protocol
- [ ] Create a simple MCP tool
- [ ] Test with external client
- [ ] Document for others

**Deliverable:** Published MCP plugin in SIDIX marketplace.

---

## SPECIALIZATION TRACKS

After Level 5, choose a specialization:

### Track A: AI/ML Engineer
- [ ] Deep dive into model architecture (Qwen, FLUX)
- [ ] Implement new generative models
- [ ] Optimize inference speed
- [ ] Research SOTA techniques

### Track B: Backend Engineer
- [ ] Scale database architecture
- [ ] Implement caching strategies
- [ ] Optimize API performance
- [ ] Build microservices

### Track C: Frontend Engineer
- [ ] Build advanced editor features
- [ ] Implement real-time collaboration
- [ ] Optimize React performance
- [ ] Build mobile app

### Track D: DevOps Engineer
- [ ] Build CI/CD pipelines
- [ ] Implement monitoring
- [ ] Manage infrastructure
- [ ] Security hardening

### Track E: Product/UX Designer
- [ ] Design new features
- [ ] Conduct user research
- [ ] Create design system
- [ ] Write product specs

### Track F: Islamic Content Specialist
- [ ] Expand IHOS corpus
- [ ] Verify Maqashid rules
- [ ] Create religious content
- [ ] Validate scholarly accuracy

---

## ASSESSMENT CHECKLIST

| Level | Assessment | Pass Criteria |
|-------|------------|---------------|
| 0 | Setup environment | Can run SIDIX locally |
| 1 | IHOS quiz | 80% correct on 20 questions |
| 2 | Typo test | Correct 20/20 typos |
| 3 | Tool creation | Working tool merged |
| 4 | Campaign creation | Generate full campaign in < 10 min |
| 5 | Persona creation | New persona accepted by team |

---

## RESOURCES

### Documentation
- `01_PRD.md` — Product requirements
- `02_ERD.md` — Database schema
- `03_ARCHITECTURE.md` — System design
- `04_FRAMEWORK.md` — Philosophy & framework
- `05_MODULES.md` — Module specs

### External Learning
- [Hugging Face Course](https://huggingface.co/learn)
- [FastAPI Docs](https://fastapi.tiangolo.com/)
- [Neo4j Graph Academy](https://neo4j.com/graphacademy/)
- [Tailwind CSS Docs](https://tailwindcss.com/docs)

### Community
- GitHub Discussions (enable in repo)
- Discord/Telegram group (when created)
- Weekly standup (if team grows)

---

> **"The one who knows himself knows his Lord."** — Ibn Arabi
> 
> *In SIDIX, knowing the system is knowing how to serve humanity better.*
